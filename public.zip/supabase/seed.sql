-- ─────────────────────────────────────────────────────────────
-- supabase/seed.sql
-- Idempotent Master Seeds (Categories, Products, Dairies, App Settings)
-- ─────────────────────────────────────────────────────────────

-- 1. Product Categories (No predefined categories; created on-demand by user)

-- 2. Products Master
INSERT INTO public.products_master (product_key, product_name, short_name, category, sort_order, is_active, is_default, created_by, updated_by)
VALUES
  ('wh_milk', 'Whole Milk', 'WM', NULL, 1, true, false, 'seed', 'seed'),
  ('dlt_milk', 'DLT Milk', 'DLT', NULL, 2, true, true, 'seed', 'seed'),
  ('fc_milk', 'FC Milk', 'FC', NULL, 3, true, false, 'seed', 'seed'),
  ('std_milk', 'STD Milk', 'STD', NULL, 4, true, false, 'seed', 'seed'),
  ('dtm', 'DTM', 'DTM', NULL, 5, true, false, 'seed', 'seed'),
  ('skim_milk', 'Skim Milk', 'SSM', NULL, 6, true, false, 'seed', 'seed'),
  ('cream', 'Cream', 'CRM', NULL, 7, true, false, 'seed', 'seed'),
  ('butter_milk', 'Butter Milk', 'BM', NULL, 8, true, false, 'seed', 'seed'),
  ('r_con', 'R.Con', 'RC', NULL, 9, true, false, 'seed', 'seed'),
  ('smp', 'SMP', 'SMP', NULL, 10, true, false, 'seed', 'seed'),
  ('water', 'Water', 'WTR', NULL, 11, true, false, 'seed', 'seed')
ON CONFLICT (product_key) DO UPDATE SET
  product_name = EXCLUDED.product_name,
  short_name = EXCLUDED.short_name,
  category = EXCLUDED.category,
  sort_order = EXCLUDED.sort_order,
  is_active = EXCLUDED.is_active;

-- 3. Dairy Destinations Master
INSERT INTO public.dairy_destinations_master (dairy_name, code, sort_order, is_active, created_by, updated_by)
VALUES
  ('Madurai-SSM', 'MDU', 1, true, 'seed', 'seed'),
  ('SNR-SSM', 'SNR', 2, true, 'seed', 'seed'),
  ('Erode-SSM', 'ERD', 3, true, 'seed', 'seed'),
  ('CBE-SSM', 'CBE', 4, true, 'seed', 'seed'),
  ('AMBATTUR-SSM', 'AMB', 5, true, 'seed', 'seed'),
  ('DCPP-SSM', 'DCPP', 6, true, 'seed', 'seed'),
  ('Tiruppur-SSM', 'TPR', 7, true, 'seed', 'seed'),
  ('Salem-SSM', 'SLM', 8, true, 'seed', 'seed')
ON CONFLICT (dairy_name) DO UPDATE SET
  code = EXCLUDED.code,
  sort_order = EXCLUDED.sort_order,
  is_active = EXCLUDED.is_active;

-- 4. App Settings
INSERT INTO public.app_settings (key, value, updated_by)
VALUES
  ('calc_config', '{
    "CMPDD_NORM_PCT": 0.5,
    "SP_GR_FACTOR_FAT": 0.2,
    "SP_GR_FACTOR_SNF": 0.36,
    "SP_GR_BASE": 250,
    "DEFAULT_DECIMALS": 3,
    "KG_FAT_DECIMALS": 3,
    "KG_SNF_DECIMALS": 3,
    "PCT_DECIMALS": 2,
    "ORG_NAME": "Namakkal District Co-operative Milk Producers Union Ltd.",
    "ORG_SHORT": "Aavin NKL"
  }'::jsonb, 'seed')
ON CONFLICT (key) DO UPDATE SET
  value = EXCLUDED.value;

