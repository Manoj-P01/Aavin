-- ============================================================
-- 024_migrate_1970_settings_to_app_settings.sql
-- Move system settings out of entries table into app_settings.
-- Remove legacy 1970-01-0x placeholder hack.
-- ============================================================

-- 1. Ensure app_settings exists
CREATE TABLE IF NOT EXISTS public.app_settings (
  key             text PRIMARY KEY,
  value           jsonb NOT NULL,
  effective_from  date DEFAULT CURRENT_DATE,
  updated_by      text DEFAULT 'admin',
  updated_at      timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.app_settings IS 'Global system, shift and calculation configuration.';

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all app_settings" ON public.app_settings;
CREATE POLICY "Allow all app_settings" 
  ON public.app_settings 
  FOR ALL USING (true) WITH CHECK (true);

-- 2. Backup table: create structure and preserve rows to be migrated
CREATE TABLE IF NOT EXISTS public.entries_settings_backup AS 
SELECT * FROM public.entries WHERE false;

-- Backup candidate rows
INSERT INTO public.entries_settings_backup
SELECT * FROM public.entries
WHERE (
  (report_type = 'STOCK' AND shift IS NULL AND notes ~ '^\s*\{' AND (notes LIKE '%"mode"%' OR notes LIKE '%"shifts"%') AND notes NOT LIKE '%__METADATA__:%')
  OR report_type = 'STG_CALC_CONFIG'
  OR entry_date IN (DATE '1970-01-01', DATE '1970-01-02', DATE '1970-01-03', DATE '1970-01-04')
)
ON CONFLICT DO NOTHING;

-- 3. Copy shift_config data to app_settings (latest valid row)
INSERT INTO public.app_settings (key, value, updated_by, updated_at)
SELECT
  'shift_config',
  notes::jsonb,
  COALESCE(updated_by, 'admin'),
  COALESCE(updated_at, now())
FROM public.entries
WHERE report_type = 'STOCK'
  AND shift IS NULL
  AND notes ~ '^\s*\{'
  AND (notes LIKE '%"mode"%' OR notes LIKE '%"shifts"%')
  AND notes NOT LIKE '%__METADATA__:%'
ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
LIMIT 1
ON CONFLICT (key) DO UPDATE
SET value = EXCLUDED.value,
    updated_at = EXCLUDED.updated_at,
    updated_by = EXCLUDED.updated_by;

-- 4. Copy stg_calc_config data to app_settings (latest valid row)
INSERT INTO public.app_settings (key, value, updated_by, updated_at)
SELECT
  'stg_calc_config',
  notes::jsonb,
  COALESCE(updated_by, 'admin'),
  COALESCE(updated_at, now())
FROM public.entries
WHERE report_type = 'STG_CALC_CONFIG'
  AND notes ~ '^\s*\{'
ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
LIMIT 1
ON CONFLICT (key) DO UPDATE
SET value = EXCLUDED.value,
    updated_at = EXCLUDED.updated_at,
    updated_by = EXCLUDED.updated_by;

-- 5. Delete only the migrated rows from entries (referenced in backup)
DELETE FROM public.entries
WHERE id IN (
  SELECT id FROM public.entries_settings_backup
);

-- 6. Add constraint to prevent writing fake 1970 dates again
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'entries_real_date_chk'
  ) THEN
    ALTER TABLE public.entries 
    ADD CONSTRAINT entries_real_date_chk CHECK (entry_date >= DATE '2000-01-01') NOT VALID;
  END IF;
END $$;

