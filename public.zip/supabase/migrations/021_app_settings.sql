-- ============================================================
-- 021_app_settings.sql
-- Table for dynamic application settings, calculation formulas and plant norms
-- ============================================================

CREATE TABLE IF NOT EXISTS public.app_settings (
  key             text PRIMARY KEY,
  value           jsonb NOT NULL,
  effective_from  date DEFAULT CURRENT_DATE,
  updated_by      text DEFAULT 'admin',
  updated_at      timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.app_settings IS 'Global system and calculation settings (e.g. calculation parameters, CMPDD norm %, decimal rounding).';

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all app_settings" ON public.app_settings;
CREATE POLICY "Allow all app_settings" 
  ON public.app_settings 
  FOR ALL USING (true) WITH CHECK (true);

-- Seed initial calculation constants
INSERT INTO public.app_settings (key, value)
VALUES (
  'calc_config',
  '{
    "SP_GR": {
      "BASE": 1,
      "FAT_FACTOR": 0.2,
      "OFFSET": 0.36,
      "DIVISOR": 250,
      "DECIMALS": 4
    },
    "QTY_KG": {
      "DECIMALS": 3
    },
    "KG_FAT": {
      "DIVISOR": 100,
      "DECIMALS": 3,
      "TS_DECIMALS": 4
    },
    "KG_SNF": {
      "DIVISOR": 100,
      "DECIMALS": 3,
      "TS_DECIMALS": 4
    },
    "TS_REPORT": {
      "QTY_LTS_DECIMALS": 3,
      "QTY_KG_DECIMALS": 3,
      "LOSS_PERCENTAGE_DECIMALS": 4,
      "CMPDD_NORM_PCT": 0.5
    }
  }'::jsonb
)
ON CONFLICT (key) DO NOTHING;

