'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import StockReport from '@/components/reports/StockReport';
import Link from 'next/link';
import { useConfirm } from '@/context/ConfirmContext';
import { useShiftConfig } from '@/hooks/useSettings';
import { fmtDate, calcStockSummary, combineShiftSummaries } from '@/lib/calculations';
import type { StockRow, Shift } from '@/lib/types';

interface ShiftData {
  rows: StockRow[];
}

export default function StockViewPage() {
  const { showError } = useConfirm();
  const { date, shift } = useParams<{ date: string; shift: string }>();
  const router = useRouter();
  const { shiftConfig } = useShiftConfig();
  const [data, setData] = useState<ShiftData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<'shift' | 'combined'>('shift');
  const [reportMode, setReportMode] = useState<'full_day' | 'shift'>('full_day');
  const [globalProducts, setGlobalProducts] = useState<any[]>([]);
  const [entryNotes, setEntryNotes] = useState<string | null>(null);
  const [otherNotes, setOtherNotes] = useState<string | null>(null);

  // Also load the opposite shift for combined view
  const [otherShiftData, setOtherShiftData] = useState<ShiftData | null>(null);
  const otherShift: Shift = shift === 'D' ? 'N' : 'D';

  const handleExportStockExcel = async () => {
    try {
      const url = `/api/export-excel?date=${date}&shift=${shift}&stock=true`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Export failed');
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      const dateParts = date.split('-');
      const formattedDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
      const shiftStr = shift ? `-${shift}` : '';
      a.download = `${formattedDate}${shiftStr}-Stock-Statement.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error(err);
      await showError('Failed to export Excel report', 'Export Error');
    }
  };

  useEffect(() => {
    if (!date) return;

    // Handle dynamic route fallback collision for preparation-charts
    if (date === 'preparation-charts') {
      router.replace(`/dashboard/stock/preparation-charts/${shift}`);
      return;
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      router.replace('/dashboard/stock');
      return;
    }

    async function load() {
      try {
        // Load report mode configuration & database products master
        const parsedMode: 'full_day' | 'shift' = shiftConfig?.mode || 'full_day';
        setReportMode(parsedMode);

        try {
          const stockCfgRes = await fetch('/api/stock/config');
          if (stockCfgRes.ok) {
            const stockCfg = await stockCfgRes.json();
            if (Array.isArray(stockCfg.products) && stockCfg.products.length > 0) {
              setGlobalProducts(stockCfg.products.map((p: any) => ({
                key: p.key || p.product_key,
                label: p.short_name || p.full_name || p.label || p.key,
                full_name: p.full_name || p.product_name,
                short_name: p.short_name || p.code,
              })));
            }
          }
        } catch (err) {
          console.error('Error loading shift config in stock page:', err);
        }
        setReportMode(parsedMode);

        // Load this shift
        const res = await fetch(`/api/stock?date=${date}&shift=${shift}`);
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Not found');

        const entry = json.data?.entries?.[0];
        if (!entry) throw new Error('Entry not found');

        setEntryNotes(entry.notes);

        const shiftRows = json.data.stock_rows.filter((r: StockRow) => r.entry_id === entry.id);
        setData({ rows: shiftRows });

        // Try to load the other shift too if in shift-wise mode
        if (parsedMode === 'shift') {
          try {
            const res2 = await fetch(`/api/stock?date=${date}&shift=${otherShift}`);
            if (res2.ok) {
              const json2 = await res2.json();
              const entry2 = json2.data?.entries?.[0];
              if (entry2) {
                setOtherNotes(entry2.notes);
                const rows2 = json2.data.stock_rows.filter((r: StockRow) => r.entry_id === entry2.id);
                setOtherShiftData({ rows: rows2 });
              }
            }
          } catch { /* other shift may not exist */ }
        }

      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : 'Failed to load');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [date, shift, otherShift]);

  // Combined view: merge both shifts
  const getCombinedRows = (): { rows: StockRow[] } => {
    if (!data || !otherShiftData) return data || { rows: [] };
    const dayData = shift === 'D' ? data : otherShiftData;
    const nightData = shift === 'N' ? data : otherShiftData;
    const daySummary = calcStockSummary(dayData.rows);
    const nightSummary = calcStockSummary(nightData.rows);
    const combined = combineShiftSummaries(daySummary, nightSummary);

    // Build synthetic rows for combined display (no physical count)
    const syntheticRows: StockRow[] = [
      { id: 'ob', entry_id: 'combined', row_type: 'OB', row_label: 'Opening Balance', sort_order: 0, ...combined.opening_balance },
      ...combined.total_receipts ? [{ id: 'rec', entry_id: 'combined', row_type: 'RECEIPT' as const, row_label: 'Receipts:', sort_order: 1, ...combined.total_receipts }] : [],
      ...combined.total_disposals ? [{ id: 'dis', entry_id: 'combined', row_type: 'DISPOSAL' as const, row_label: 'Disposals', sort_order: 2, ...combined.total_disposals }] : [],
    ];
    return { rows: syntheticRows };
  };

  const displayData = viewMode === 'combined' ? getCombinedRows() : (data || { rows: [] });

  return (
    <>
      <Header
        title={`Stock Statement – ${date ? fmtDate(date) : ''}`}
        subtitle={reportMode === 'full_day' ? 'Full Day' : `Shift: ${shift === 'D' ? 'Day' : 'Night'}`}
        actions={
          <div style={{ display: 'flex', gap: 8 }} className="no-print">
            {reportMode === 'shift' && otherShiftData && (
              <div className="tabs">
                <button
                  className={`tab ${viewMode === 'shift' ? 'active' : ''}`}
                  onClick={() => setViewMode('shift')}
                >
                  {shift === 'D' ? '☀️ Day' : '🌙 Night'}
                </button>
                <button
                  className={`tab ${viewMode === 'combined' ? 'active' : ''}`}
                  onClick={() => setViewMode('combined')}
                >
                  🌓 Combined Day
                </button>
              </div>
            )}
            <button className="btn btn-secondary btn-sm no-print" onClick={() => window.print()}>🖨 Print / PDF</button>
            <button className="btn btn-secondary btn-sm no-print" style={{ borderColor: '#16a34a', color: '#16a34a' }} onClick={handleExportStockExcel}>📥 Export Excel</button>
            <Link href="/dashboard/stock" className="btn btn-ghost btn-sm">← Back</Link>
          </div>
        }
      />
      <div className="page-body animate-fade-in">
        {/* Date Selector Bar */}
        <div
          className="card no-print"
          style={{
            marginBottom: 16,
            padding: '10px 16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'rgba(14, 165, 233, 0.05)',
            border: '1px solid rgba(14, 165, 233, 0.2)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <label
              htmlFor="stock-view-date-picker"
              style={{
                fontWeight: 700,
                fontSize: '0.85rem',
                color: 'var(--text-primary)',
                margin: 0,
                display: 'flex',
                alignItems: 'center',
                gap: 6,
              }}
            >
              📅 Select Date to View Statement:
            </label>
            <input
              id="stock-view-date-picker"
              type="date"
              className="form-input"
              value={date}
              onChange={e => {
                if (e.target.value) {
                  router.push(`/dashboard/stock/${e.target.value}/${shift}`);
                }
              }}
              style={{
                width: 160,
                padding: '6px 12px',
                margin: 0,
                fontSize: '0.85rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            />
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
            Selected Date: <strong style={{ color: 'var(--brand-primary)' }}>{fmtDate(date)}</strong>
          </div>
        </div>

        {/* Other shift link */}
        {!loading && !error && reportMode === 'shift' && (
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }} className="no-print">
            <Link
              href={`/dashboard/stock/${date}/${otherShift}`}
              className="btn btn-secondary btn-sm"
            >
              View {otherShift === 'D' ? '☀️ Day' : '🌙 Night'} Shift →
            </Link>
          </div>
        )}

        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 40 }}>
            <span className="spinner" /> Loading report...
          </div>
        ) : error ? (
          <div className="alert alert-error">
            ⚠️ {error}
            <button onClick={() => router.back()} style={{ marginLeft: 12 }} className="btn btn-ghost btn-sm">Go Back</button>
          </div>
        ) : (
          <div className="card">
            <StockReport
              rows={displayData.rows}
              date={date}
              shift={reportMode === 'full_day' ? 'FULL_DAY' : (viewMode === 'combined' ? 'COMBINED' : (shift === 'N' ? 'N' : 'D'))}
              notes={viewMode === 'combined' ? `${entryNotes || ''}\n${otherNotes || ''}` : entryNotes}
              products={globalProducts}
            />
          </div>
        )}
      </div>
    </>
  );
}
