import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import { getSupabaseServiceClient } from '@/lib/supabase';
import { TS_OB_PRODUCTS, TS_RECEIPT_PRODUCTS, TS_DESPATCH_PRODUCTS, TS_LOCAL_SALE_PRODUCTS, TS_OTHER_DISPOSAL_PRODUCTS } from '@/lib/types';
import type { TSSection, StockRowType, Shift } from '@/lib/types';
import { packRows } from '@/lib/rowJson';

// Helper: parse date from Excel format
function parseExcelDate(val: any): string {
  if (val instanceof Date) {
    return val.toISOString().split('T')[0];
  }
  if (typeof val === 'number') {
    // Excel serial number format
    const d = new Date((val - 25569) * 86400 * 1000);
    return d.toISOString().split('T')[0];
  }
  if (typeof val === 'string') {
    // e.g. "01-06-2026"
    const match = val.match(/(\d{2})[-/](\d{2})[-/](\d{4})/);
    if (match) return `${match[3]}-${match[2]}-${match[1]}`;
  }
  return new Date().toISOString().split('T')[0];
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;
    const reportType = formData.get('report_type') as string; // 'TS' or 'STOCK'

    if (!file) return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });

    const bytes = await file.arrayBuffer();
    const workbook = XLSX.read(bytes, { type: 'array', cellDates: true });

    const supabase = getSupabaseServiceClient();

    let activeProds: any[] = [];
    const { data: dbProds } = await supabase
      .from('products_master')
      .select('id, product_key, product_name, short_name, category, sort_order, is_active')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (dbProds) activeProds = dbProds;

    let importedCount = 0;

    if (reportType === 'TS') {
      // ─── PARSE TS REPORT ───────────────────────────────────────────────────
      const sheet = workbook.Sheets['TS'];
      if (!sheet) return NextResponse.json({ error: 'Sheet "TS" not found in workbook' }, { status: 400 });

      const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:R40');
      const rows: any[] = [];
      for (let r = range.s.r; r <= range.e.r; r++) {
        const row: any[] = [];
        for (let c = range.s.c; c <= range.e.c; c++) {
          const cell = sheet[XLSX.utils.encode_cell({ r, c })];
          row.push(cell ? cell.v : null);
        }
        rows.push(row);
      }

      // Try to find Date in sheet
      let entryDate = new Date().toISOString().split('T')[0];
      for (let r = 0; r < Math.min(10, rows.length); r++) {
        for (let c = 0; c < rows[r].length; c++) {
          const v = rows[r][c];
          if (v instanceof Date) {
            entryDate = v.toISOString().split('T')[0];
            break;
          }
        }
      }

      // We read O/B, Receipts, Despatch, Local Sales, Other Disposal, CB
      const tsRows: any[] = [];

      let currentLeftSection: TSSection = 'OB';
      let currentRightSection: TSSection = 'DISPOSAL_DESPATCH';

      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length < 5) continue;

        // Left Side: Arrival (cols 0-8)
        const leftProd = row[1] ? String(row[1]).trim() : null;
        if (leftProd === 'TOTAL') {
          // transition left
          currentLeftSection = 'RECEIPT';
        }

        if (leftProd && leftProd !== 'Arrival' && leftProd !== 'O/B' && leftProd !== 'TOTAL' && leftProd !== 'RECEIPTS') {
          const section: TSSection = (TS_OB_PRODUCTS as readonly string[]).includes(leftProd) && currentLeftSection === 'OB' ? 'OB' : 'RECEIPT';
          tsRows.push({
            section,
            product: leftProd,
            qty_lts: Number(row[2]) || 0,
            qty_kg: Number(row[3]) || 0,
            fat_pct: Number(row[4]) || 0,
            snf_pct: Number(row[5]) || 0,
            sp_gr: Number(row[6]) || 0,
            kg_fat: Number(row[7]) || 0,
            kg_snf: Number(row[8]) || 0,
            remarks: '',
          });
        }

        // Right Side: Disposal (cols 9-17)
        const rightProd = row[10] ? String(row[10]).trim() : null;
        if (rightProd === 'C/B' || rightProd === 'CB') {
          currentRightSection = 'CB';
        }

        if (rightProd && rightProd !== 'Disposal' && rightProd !== 'TOTAL' && rightProd !== 'C/B') {
          let section: TSSection = 'CB';
          if (currentRightSection !== 'CB') {
            if ((TS_DESPATCH_PRODUCTS as readonly string[]).includes(rightProd)) section = 'DISPOSAL_DESPATCH';
            else if ((TS_LOCAL_SALE_PRODUCTS as readonly string[]).includes(rightProd)) section = 'LOCAL_SALE';
            else section = 'OTHER_DISPOSAL';
          }
          tsRows.push({
            section,
            product: rightProd,
            qty_lts: Number(row[11]) || 0,
            qty_kg: Number(row[12]) || 0,
            fat_pct: Number(row[13]) || 0,
            snf_pct: Number(row[14]) || 0,
            sp_gr: Number(row[15]) || 0,
            kg_fat: Number(row[16]) || 0,
            kg_snf: Number(row[17]) || 0,
            remarks: '',
          });
        }
      }

      // Try to parse STG sheet too if present in the workbook!
      const stgSheet = workbook.Sheets['STG'];
      const stgRows: any[] = [];
      if (stgSheet) {
        const stgRange = XLSX.utils.decode_range(stgSheet['!ref'] || 'A1:R80');
        const sRows: any[] = [];
        for (let r = stgRange.s.r; r <= stgRange.e.r; r++) {
          const row: any[] = [];
          for (let c = stgRange.s.c; c <= stgRange.e.c; c++) {
            const cell = stgSheet[XLSX.utils.encode_cell({ r, c })];
            row.push(cell ? cell.v : null);
          }
          sRows.push(row);
        }

        let currentBlock: string | null = null;

        for (let r = 0; r < sRows.length; r++) {
          const row = sRows[r];
          if (!row || row.length === 0) continue;

          const title = row[0] ? String(row[0]).trim() : '';

          // Detect block header dynamically
          let matchedBlock = '';
          if (activeProds && activeProds.length > 0) {
            for (const p of activeProds) {
              const pKey = (p.product_key || p.key || '').toUpperCase();
              const pShort = (p.short_name || '').toUpperCase();
              const pName = (p.product_name || p.full_name || '').toUpperCase();
              if ((pShort && title.includes(pShort)) || (pName && title.includes(pName)) || (pKey && title.includes(pKey))) {
                matchedBlock = pShort || pKey;
                break;
              }
            }
          }
          if (!matchedBlock && (title.includes('STATEMENT') || title.includes('RECEIPT AND DISPOSAL'))) {
            matchedBlock = title.split('–')[0].split('-')[0].replace('STATEMENT', '').trim().toUpperCase();
          }

          if (matchedBlock) {
            currentBlock = matchedBlock;
            continue;
          }

          if (!currentBlock) continue;

          // Left Side: Receipt
          const leftName = row[1] ? String(row[1]).trim() : null;
          if (leftName && leftName !== 'Receipt' && leftName !== 'Total' && leftName !== 'OB' && leftName !== 'Grand Total' && leftName !== 'Loss/Gain' && leftName !== 'S.No.') {
            stgRows.push({
              product_block: currentBlock,
              side: 'RECEIPT',
              item_name: leftName,
              qty_lts: Number(row[2]) || 0,
              qty_kg: Number(row[3]) || 0,
              fat_pct: Number(row[4]) || 0,
              snf_pct: Number(row[5]) || 0,
              sp_gr: Number(row[6]) || 0,
              kg_fat: Number(row[7]) || 0,
              kg_snf: Number(row[8]) || 0,
            });
          }

          // Right Side: Disposal
          const rightName = row[10] ? String(row[10]).trim() : null;
          if (rightName && rightName !== 'Disposal' && rightName !== 'Total' && rightName !== 'CB' && rightName !== 'Grand Total' && rightName !== 'Loss/Gain' && rightName !== 'S.No.') {
            stgRows.push({
              product_block: currentBlock,
              side: 'DISPOSAL',
              item_name: rightName,
              qty_lts: Number(row[11]) || 0,
              qty_kg: Number(row[12]) || 0,
              fat_pct: Number(row[13]) || 0,
              snf_pct: Number(row[14]) || 0,
              sp_gr: Number(row[15]) || 0,
              kg_fat: Number(row[16]) || 0,
              kg_snf: Number(row[17]) || 0,
            });
          }
        }
      }

      // Persist
      const { data: entry, error: entErr } = await supabase
        .from('entries')
        .insert({ entry_date: entryDate, report_type: 'TS' })
        .select()
        .single();
      if (entErr && entErr.code !== '23505') throw entErr;

      let entryId = entry?.id;
      if (!entryId) {
        const { data: ext } = await supabase.from('entries').select('id').eq('entry_date', entryDate).eq('report_type', 'TS').single();
        entryId = ext?.id;
      }

      if (entryId) {
        await Promise.all([
          supabase.from('ts_milk_rows').delete().eq('entry_id', entryId),
          supabase.from('stg_rows').delete().eq('entry_id', entryId),
        ]);
        const packedTsRows = packRows(
          tsRows.map((r, sort_order) => ({ ...r, entry_id: entryId, sort_order })),
          'ts'
        );
        const packedStgRows = packRows(
          stgRows.map((r, sort_order) => ({ ...r, entry_id: entryId, sort_order })),
          'stg'
        );
        await Promise.all([
          supabase.from('ts_milk_rows').insert(packedTsRows),
          packedStgRows.length > 0 ? supabase.from('stg_rows').insert(packedStgRows) : Promise.resolve(),
        ]);
      }
      importedCount = 1;

    } else if (reportType === 'STOCK') {
      // ─── PARSE STOCK REGISTER ─────────────────────────────────────────────
      // Loop over sheets (could be one shift or multiple daily tabs)
      for (const sheetName of workbook.SheetNames) {
        // e.g. "1-06-2026D" or "01-06-2026N"
        const match = sheetName.match(/(\d{1,2}-\d{1,2}-\d{4})([DN])/);
        if (!match) continue;

        const dateParts = match[1].split('-');
        const entryDate = `${dateParts[2]}-${dateParts[1].padStart(2, '0')}-${dateParts[0].padStart(2, '0')}`;
        const shift = match[2] as Shift;

        const sheet = workbook.Sheets[sheetName];
        if (!sheet) continue;

        // Parse sheet table grid rows
        const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:T33');
        const sheetRows: any[] = [];
        for (let r = range.s.r; r <= range.e.r; r++) {
          const row: any[] = [];
          for (let c = range.s.c; c <= range.e.c; c++) {
            const cell = sheet[XLSX.utils.encode_cell({ r, c })];
            row.push(cell ? cell.v : null);
          }
          sheetRows.push(row);
        }

        const stockRows: any[] = [];

        let activeCols: string[] = activeProds.map((p: any) => p.product_key || p.key || p.short_name);

        let currentType: StockRowType = 'OB';

        for (let r = 2; r < sheetRows.length; r++) {
          const row = sheetRows[r];
          if (!row || row.length < 2) continue;

          const label = row[0] ? String(row[0]).trim() : '';
          if (!label) continue;

          if (label === 'Receipts:') {
            currentType = 'RECEIPT';
            continue;
          }
          if (label === 'Disposals:') {
            currentType = 'DISPOSAL';
            continue;
          }
          if (label === 'physical') {
            continue;
          }

          if (label === 'TOTAL' || label === 'difference' || label === 'Closing Balance' || label === 'DATE') continue;

          // Skip details/breakdown rows
          if (label === 'Details' || label === 'WM' || label === 'SSM (Lts)' || label === 'Cream (Lts)') {
            continue;
          }

          // Build row record
          const rowRecord: any = {
            row_type: currentType,
            row_label: label,
          };

          for (let c = 0; c < activeCols.length; c++) {
            rowRecord[activeCols[c]] = Number(row[c + 1]) || 0;
          }

          stockRows.push(rowRecord);
        }

        // Persist
        const { data: entry, error: entErr } = await supabase
          .from('entries')
          .insert({ entry_date: entryDate, shift, report_type: 'STOCK' })
          .select()
          .single();
        if (entErr && entErr.code !== '23505') throw entErr;

        let entryId = entry?.id;
        if (!entryId) {
          const { data: ext } = await supabase.from('entries').select('id').eq('entry_date', entryDate).eq('shift', shift).eq('report_type', 'STOCK').single();
          entryId = ext?.id;
        }

        if (entryId) {
          await supabase.from('stock_rows').delete().eq('entry_id', entryId);

          const sectionTypes: Array<{ type: 'OB' | 'RECEIPT' | 'DISPOSAL'; label: string; order: number }> = [
            { type: 'OB', label: 'Opening Balance', order: 0 },
            { type: 'RECEIPT', label: 'Receipts', order: 1 },
            { type: 'DISPOSAL', label: 'Disposals', order: 2 },
          ];

          const rowsToInsert: any[] = [];
          sectionTypes.forEach(sec => {
            const matching = stockRows.filter((r: any) => r.row_type === sec.type);
            if (matching.length === 0 && sec.type !== 'OB') return;

            const innerRows = matching.map((r: any, idx: number) => {
              const vals: Record<string, number> = {};
              Object.entries(r).forEach(([k, v]) => {
                if (!['entry_id', 'row_type', 'row_label', 'sort_order', 'entry_json', 'values', 'id', 'created_at', 'updated_at', 'created_by', 'updated_by'].includes(k) && typeof v !== 'object') {
                  const normK = k.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
                  vals[normK] = Number(v) || 0;
                }
              });

              if (r.values && typeof r.values === 'object') {
                Object.entries(r.values).forEach(([vk, vv]) => {
                  const normVK = vk.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
                  const num = Number(vv) || 0;
                  if (vals[normVK] === undefined || (vals[normVK] === 0 && num !== 0)) {
                    vals[normVK] = num;
                  }
                });
              }

              return {
                row_label: r.row_label || '',
                values: vals,
                sort_order: idx,
              };
            });

            rowsToInsert.push({
              entry_id: entryId,
              row_type: sec.type,
              row_label: sec.label,
              sort_order: sec.order,
              entry_json: {
                rows: innerRows,
              },
            });
          });

          if (rowsToInsert.length > 0) {
            const { error: insertErr } = await supabase.from('stock_rows').insert(rowsToInsert);
            if (insertErr && String(insertErr.message || '').toLowerCase().includes('entry_json')) {
              const fallbackRows = (stockRows || []).map((r: any, idx: number) => ({
                entry_id: entryId,
                row_type: r.row_type,
                row_label: r.row_label,
                sort_order: r.sort_order ?? idx,
              }));
              await supabase.from('stock_rows').insert(fallbackRows);
            }
          }
        }
        importedCount++;
      }
    }

    return NextResponse.json({ success: true, count: importedCount });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
