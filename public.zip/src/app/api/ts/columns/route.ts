import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceClient } from '@/lib/supabase';
import { getAuthUserFromRequest } from '@/lib/auth';

export interface STGColumnDef {
  key: string;
  name: string;
  type: 'number' | 'text' | 'calculated';
  formula?: string;
  unit?: string;
  decimals?: number;
  sort_order?: number;
  is_active?: boolean;
}

export interface STGColumnSections {
  ob: STGColumnDef[];
  receipt: STGColumnDef[];
  disposal: STGColumnDef[];
  cb: STGColumnDef[];
}

export const DEFAULT_STG_SECTIONS: STGColumnSections = {
  ob: [],
  receipt: [],
  disposal: [],
  cb: [],
};

export const DEFAULT_STG_COLUMNS: STGColumnDef[] = [];

// GET /api/ts/columns - Fetch STG column definitions strictly from DB table prep_chart_configs
export async function GET(req: NextRequest) {
  try {
    const supabase = getSupabaseServiceClient();

    const { data: res, error } = await supabase
      .from('prep_chart_configs')
      .select('config_json')
      .eq('config_key', 'stg_columns')
      .maybeSingle();

    let sections: STGColumnSections = {
      ob: [],
      receipt: [],
      disposal: [],
      cb: [],
    };

    if (!error && res && res.config_json) {
      if (Array.isArray(res.config_json)) {
        // Legacy flat array format: replicate to all sections
        sections = {
          ob: res.config_json,
          receipt: res.config_json,
          disposal: res.config_json,
          cb: res.config_json,
        };
      } else if (typeof res.config_json === 'object') {
        sections = {
          ob: Array.isArray(res.config_json.ob) ? res.config_json.ob : (Array.isArray(res.config_json.ob_columns) ? res.config_json.ob_columns : []),
          receipt: Array.isArray(res.config_json.receipt) ? res.config_json.receipt : (Array.isArray(res.config_json.receipt_columns) ? res.config_json.receipt_columns : []),
          disposal: Array.isArray(res.config_json.disposal) ? res.config_json.disposal : (Array.isArray(res.config_json.disposal_columns) ? res.config_json.disposal_columns : []),
          cb: Array.isArray(res.config_json.cb) ? res.config_json.cb : (Array.isArray(res.config_json.recon_columns) ? res.config_json.recon_columns : (Array.isArray(res.config_json.cb_columns) ? res.config_json.cb_columns : [])),
        };
      }
    }

    // Produce flat columns list for backwards compatibility
    const allColsMap = new Map<string, STGColumnDef>();
    [...sections.receipt, ...sections.ob, ...sections.disposal, ...sections.cb].forEach(c => {
      if (c && c.key && !allColsMap.has(c.key)) {
        allColsMap.set(c.key, c);
      }
    });
    const flatColumns = Array.from(allColsMap.values());

    return NextResponse.json({ success: true, sections, columns: flatColumns });
  } catch (err: any) {
    console.error('GET /api/ts/columns error:', err);
    return NextResponse.json({ success: true, sections: DEFAULT_STG_SECTIONS, columns: [] });
  }
}

// POST /api/ts/columns - Save STG column definitions by section to prep_chart_configs and synchronize all statement masters
export async function POST(req: NextRequest) {
  try {
    const authUser = await getAuthUserFromRequest(req);
    const actorUsername = authUser?.username || 'admin';
    const body = await req.json();

    let sections: STGColumnSections;

    if (body.sections && typeof body.sections === 'object') {
      sections = {
        ob: Array.isArray(body.sections.ob) ? body.sections.ob : [],
        receipt: Array.isArray(body.sections.receipt) ? body.sections.receipt : [],
        disposal: Array.isArray(body.sections.disposal) ? body.sections.disposal : [],
        cb: Array.isArray(body.sections.cb) ? body.sections.cb : (Array.isArray(body.sections.recon) ? body.sections.recon : []),
      };
    } else if (Array.isArray(body.columns) || Array.isArray(body)) {
      const list = Array.isArray(body.columns) ? body.columns : body;
      sections = { ob: list, receipt: list, disposal: list, cb: list };
    } else {
      sections = {
        ob: Array.isArray(body.ob) ? body.ob : [],
        receipt: Array.isArray(body.receipt) ? body.receipt : [],
        disposal: Array.isArray(body.disposal) ? body.disposal : [],
        cb: Array.isArray(body.cb) ? body.cb : (Array.isArray(body.recon) ? body.recon : []),
      };
    }

    const supabase = getSupabaseServiceClient();

    // 1. Primary Save: store configured sections in prep_chart_configs
    const { error: upsertErr } = await supabase.from('prep_chart_configs').upsert({
      config_key: 'stg_columns',
      config_json: sections,
      updated_by: actorUsername,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'config_key' });

    if (upsertErr) throw upsertErr;

    // 2. Synchronize all existing statement masters in `stg_masters` table and `prep_chart_configs`
    const syncCols = (configuredCols: STGColumnDef[], existingCols: any[] | undefined, isRecon = false) => {
      if (!Array.isArray(configuredCols) || configuredCols.length === 0) {
        return existingCols || [];
      }
      return configuredCols.map((cfgCol: any, idx: number) => {
        const existing = Array.isArray(existingCols)
          ? existingCols.find((c: any) => c.key === cfgCol.key || (isRecon && cfgCol.key === 'variant' && c.key === 'label'))
          : null;

        const colName = existing?.name ? existing.name : cfgCol.name;
        const isHardcodedCalc = (existing?.formula === 'qty_lts * sp_gr' || cfgCol.formula === 'qty_lts * sp_gr' ||
                                 existing?.formula === 'qty_kg * fat_pct / 100' || cfgCol.formula === 'qty_kg * fat_pct / 100' ||
                                 existing?.formula === 'qty_kg * snf_pct / 100' || cfgCol.formula === 'qty_kg * snf_pct / 100');

        const isTextIdentifier = (
          cfgCol.type === 'text' || existing?.type === 'text' ||
          ['variant', 'label', 'note', 'receipt', 'disposal', 'ob', 'particular', 'name', 'item_name'].includes((cfgCol.key || '').toLowerCase()) ||
          ['variant', 'label', 'note', 'receipt', 'disposal', 'ob', 'particular', 'name', 'item_name'].includes((existing?.key || '').toLowerCase()) ||
          ['variant', 'label', 'note', 'receipt', 'disposal', 'ob', 'particular', 'name', 'item_name'].includes((colName || '').toLowerCase())
        );

        const colType = isTextIdentifier
          ? 'text'
          : (isHardcodedCalc ? 'number' : (existing?.type || cfgCol.type || 'number'));

        const formula = isHardcodedCalc ? undefined : (existing?.formula || cfgCol.formula || undefined);

        const resCol: any = {
          ...cfgCol,
          key: isRecon && (existing?.key === 'label' || cfgCol.key === 'label') ? 'label' : cfgCol.key,
          name: colName,
          type: colType,
          decimals: existing?.decimals !== undefined ? existing.decimals : cfgCol.decimals,
          unit: existing?.unit || cfgCol.unit,
          sort_order: idx + 1,
          is_active: existing?.is_active !== undefined ? existing.is_active : (cfgCol.is_active !== undefined ? cfgCol.is_active : true),
        };

        if (formula) resCol.formula = formula;
        else delete resCol.formula;

        return resCol;
      });
    };

    const hasAnyConfigured = sections.ob.length > 0 || sections.receipt.length > 0 || sections.disposal.length > 0 || sections.cb.length > 0;

    if (hasAnyConfigured) {
      try {
        const { data: stgRows, error: stgErr } = await supabase
          .from('stg_masters')
          .select('id, key, label, variant, description, sort_order, is_active, ob_columns, receipt_columns, disposal_columns, recon_columns, ob_rows, receipt_rows, disposal_rows, reconciliation_rows, updated_at');

        if (!stgErr && Array.isArray(stgRows) && stgRows.length > 0) {
          const updatedStgRows = stgRows.map((r: any) => ({
            ...r,
            ob_columns: sections.ob.length > 0 ? syncCols(sections.ob, r.ob_columns, false) : r.ob_columns,
            receipt_columns: sections.receipt.length > 0 ? syncCols(sections.receipt, r.receipt_columns, false) : r.receipt_columns,
            disposal_columns: sections.disposal.length > 0 ? syncCols(sections.disposal, r.disposal_columns, false) : r.disposal_columns,
            recon_columns: sections.cb.length > 0 ? syncCols(sections.cb, r.recon_columns, true) : r.recon_columns,
            updated_by: actorUsername,
            updated_at: new Date().toISOString(),
          }));

          await supabase.from('stg_masters').upsert(updatedStgRows, { onConflict: 'key' });
        }

        // 2b. Update prep_chart_configs ('stg_masters')
        const { data: stgConfig } = await supabase
          .from('prep_chart_configs')
          .select('config_json')
          .eq('config_key', 'stg_masters')
          .maybeSingle();

        if (stgConfig && Array.isArray(stgConfig.config_json) && stgConfig.config_json.length > 0) {
          const updatedMastersConfig = stgConfig.config_json.map((m: any) => ({
            ...m,
            ob_columns: sections.ob.length > 0 ? syncCols(sections.ob, m.ob_columns, false) : m.ob_columns,
            receipt_columns: sections.receipt.length > 0 ? syncCols(sections.receipt, m.receipt_columns, false) : m.receipt_columns,
            disposal_columns: sections.disposal.length > 0 ? syncCols(sections.disposal, m.disposal_columns, false) : m.disposal_columns,
            recon_columns: sections.cb.length > 0 ? syncCols(sections.cb, m.recon_columns, true) : m.recon_columns,
          }));

          await supabase.from('prep_chart_configs').upsert({
            config_key: 'stg_masters',
            config_json: updatedMastersConfig,
            updated_by: actorUsername,
            updated_at: new Date().toISOString(),
          }, { onConflict: 'config_key' });
        }
      } catch (syncErr) {
        console.warn('Failed to sync masters columns:', syncErr);
      }
    }

    // Flat columns list for response
    const allColsMap = new Map<string, STGColumnDef>();
    [...sections.receipt, ...sections.ob, ...sections.disposal, ...sections.cb].forEach(c => {
      if (c && c.key && !allColsMap.has(c.key)) {
        allColsMap.set(c.key, c);
      }
    });

    return NextResponse.json({ success: true, sections, columns: Array.from(allColsMap.values()) });
  } catch (err: any) {
    console.error('POST /api/ts/columns error:', err);
    return NextResponse.json({ error: err.message || 'Failed to save STG columns' }, { status: 500 });
  }
}
