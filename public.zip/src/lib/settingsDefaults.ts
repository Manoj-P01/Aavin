// ─────────────────────────────────────────────────────────────
// src/lib/settingsDefaults.ts
// Central Application Settings Defaults
// ─────────────────────────────────────────────────────────────

import type { ShiftConfig, StgCalcConfig } from './types';

export const DEFAULT_SHIFT_CONFIG: ShiftConfig = {
  mode: 'full_day',
  shifts: [
    { key: 'D', label: 'Day Shift', start: '06:00', end: '18:00' },
    { key: 'N', label: 'Night Shift', start: '18:00', end: '06:00' },
  ],
  products: [],
};

export const DEFAULT_STG_CALC_CONFIG: StgCalcConfig = {
  fatCalcMode: 'FROM_PCT',
  snfCalcMode: 'FROM_PCT',
  densityFactor: 1.0275,
};

