// ─────────────────────────────────────────────────────────────────────────────
// Aavin Dashboard – Milk & Cream Stock Statement Entry Form
// Supports dynamic product columns (insert at middle, delete with warnings)
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import type { Shift } from '@/lib/types';
import Header from '@/components/layout/Header';
import Step, { DAILY_ENTRY_STEP_ITEMS } from '@/components/ui/Step';
import Link from 'next/link';
import { useConfirm } from '@/context/ConfirmContext';
import { useShiftConfig } from '@/hooks/useSettings';

type ColKey = string;

interface StockRowState {
  row_type: 'OB' | 'RECEIPT' | 'DISPOSAL';
  row_label: string;
  values: Partial<Record<ColKey, string>>;
}

function makeDefaultRows(receipts: any[] = [], disposals: any[] = []): StockRowState[] {
  const make = (row_type: StockRowState['row_type'], row_label: string): StockRowState => ({
    row_type, row_label, values: {},
  });

  const getLabel = (r: any) => typeof r === 'string' ? r : (r.full_name || r.short_name || r.particular_name || r.label || '');

  const recList = receipts.map(getLabel);
  const dispList = disposals.map(getLabel);

  return [
    make('OB', 'Opening Balance'),
    ...recList.map(label => make('RECEIPT', label)),
    ...dispList.map(label => make('DISPOSAL', label)),
  ];
}

export interface StockEntryFormProps {
  stepMode?: boolean;
  activeStep?: string;
  onStepChange?: (stepKey: string) => void;
  onNextStep?: () => void;
  onPrevStep?: () => void;
  onDateShiftChange?: (date: string, shift: Shift) => void;
  initialDate?: string;
  initialShift?: Shift;
}

export default function StockEntryForm({
  stepMode = false,
  activeStep,
  onStepChange,
  onNextStep,
  onPrevStep,
  onDateShiftChange,
  initialDate,
  initialShift,
}: StockEntryFormProps = {}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { shiftConfig } = useShiftConfig();
  const { confirm, showWarning, showError, showSuccess } = useConfirm();
  const paramDate = searchParams.get('date');
  const paramShift = searchParams.get('shift');

  const [entryDate, setEntryDate] = useState(initialDate || paramDate || new Date().toISOString().split('T')[0]);
  const [shift, setShift] = useState<Shift>(initialShift || (paramShift === 'N' || paramShift === 'D' ? paramShift : 'D'));

  useEffect(() => {
    if (initialDate && initialDate !== entryDate) {
      setEntryDate(initialDate);
    }
  }, [initialDate]);

  useEffect(() => {
    if (initialShift && initialShift !== shift) {
      setShift(initialShift);
    }
  }, [initialShift]);
  const [shiftConfigs, setShiftConfigs] = useState<any[]>([
    { key: 'D', label: 'Day Shift', start: '06:00', end: '18:00' },
    { key: 'N', label: 'Night Shift', start: '18:00', end: '06:00' },
  ]);
  const [reportMode, setReportMode] = useState<'full_day' | 'shift'>('full_day');
  const [notes, setNotes] = useState('');
  const [rows, setRows] = useState<StockRowState[]>(() => makeDefaultRows([], []));
  const [globalProducts, setGlobalProducts] = useState<any[]>([]);
  const [columns, setColumns] = useState<Array<{ key: ColKey; label: string; full_name?: string; short_name?: string }>>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [configLoaded, setConfigLoaded] = useState(false);
  const [receiptRowsConfig, setReceiptRowsConfig] = useState<any[]>([]);
  const [disposalRowsConfig, setDisposalRowsConfig] = useState<any[]>([]);
  const [obUnlocked, setObUnlocked] = useState(false);
  const [receiptsUnlocked, setReceiptsUnlocked] = useState(false);
  const [disposalsUnlocked, setDisposalsUnlocked] = useState(false);
  const [internalRules, setInternalRules] = useState<any[]>([]);

  // Partition / Split Mapping Modal State
  const [partitionModalOpen, setPartitionModalOpen] = useState(false);
  const [activePartitionRowIdx, setActivePartitionRowIdx] = useState<number | null>(null);
  const [partitionModalTab, setPartitionModalTab] = useState<'RECEIPTS_PARTITION' | 'DAIRY_BREAKDOWN'>('DAIRY_BREAKDOWN');
  const [dairyBreakdowns, setDairyBreakdowns] = useState<Record<string, Array<{ dairy_name: string; product_key: string; value: string }>>>({});
  const [activeDairyBreakdownItems, setActiveDairyBreakdownItems] = useState<Array<{ dairy_name: string; product_key: string; value: string }>>([]);
  const [presetDairies, setPresetDairies] = useState<string[]>([]);
  const [newPresetInput, setNewPresetInput] = useState('');
  const [showAddPresetInput, setShowAddPresetInput] = useState(false);
  const [partitionItems, setPartitionItems] = useState<Array<{ targetKey: string; value: string }>>([
    { targetKey: 'skim_milk', value: '' },
    { targetKey: 'cream', value: '' },
  ]);

  useEffect(() => {
    async function loadMasterDairies() {
      try {
        const res = await fetch('/api/master/dairies');
        const json = await res.json();
        if (res.ok && Array.isArray(json.data) && json.data.length > 0) {
          const activeDairies = json.data.filter((d: any) => d.is_active !== false).map((d: any) => d.dairy_name);
          if (activeDairies.length > 0) {
            setPresetDairies(activeDairies);
          }
        }
      } catch (err) {
        console.warn('Failed loading master dairies:', err);
      }
    }
    loadMasterDairies();
  }, []);
  // Active/focused cursor row tracking and keyboard navigation
  const [focusedRowIdx, setFocusedRowIdx] = useState<number | null>(null);
  const [focusedColKey, setFocusedColKey] = useState<string | null>(null);
  const [viewDecimals, setViewDecimals] = useState<number | 'auto'>('auto');

  const formatCellVal = (rawVal: string | undefined, decimals: number | 'auto'): string => {
    if (rawVal === undefined || rawVal === null || rawVal.trim() === '') return '';
    const num = parseFloat(rawVal);
    if (isNaN(num)) return rawVal;
    if (decimals === 'auto') return rawVal;
    return num.toFixed(decimals);
  };

  const formatSummaryVal = (val: number, decimals: number | 'auto'): string => {
    if (isNaN(val)) return '0';
    if (val === 0) return decimals === 'auto' ? '0' : (0).toFixed(decimals);
    if (decimals === 'auto') {
      return val.toLocaleString('en-IN', { maximumFractionDigits: 3 });
    }
    return val.toLocaleString('en-IN', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  };

  const handleTableKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    rowIdx: number,
    fieldKey: string
  ) => {
    if (e.key === 'ArrowUp' || (e.key === 'Enter' && e.shiftKey)) {
      e.preventDefault();
      let prevIdx = rowIdx - 1;
      while (prevIdx >= 0) {
        const el = document.getElementById(`stock-input-${prevIdx}-${fieldKey}`) as HTMLInputElement;
        if (el && !el.disabled && !el.readOnly) {
          el.focus();
          el.select();
          break;
        }
        prevIdx--;
      }
    } else if (e.key === 'ArrowDown' || e.key === 'Enter') {
      e.preventDefault();
      let nextIdx = rowIdx + 1;
      while (nextIdx < rows.length) {
        const el = document.getElementById(`stock-input-${nextIdx}-${fieldKey}`) as HTMLInputElement;
        if (el && !el.disabled && !el.readOnly) {
          el.focus();
          el.select();
          break;
        }
        nextIdx++;
      }
    }
  };

  const applyInternalMappings = (currentRows: StockRowState[], activeRules: any[], forceSync: boolean = false): StockRowState[] => {
    if (receiptsUnlocked && !forceSync) return currentRows;
    const defaultColKey = columns[0]?.key || '';
    const defaultColLabel = columns[0]?.label || defaultColKey;
    const effectiveRules: any[] = activeRules.length > 0 ? activeRules : (defaultColKey ? [
      {
        id: 'default_disposal_to_receipt',
        sourceDisposalParticular: `To ${defaultColLabel}`,
        targetReceiptProductKey: defaultColKey,
        targetReceiptProductLabel: defaultColLabel,
        enabled: true,
      }
    ] : []);

    const enabledRules = effectiveRules.filter(r => r.enabled !== false);
    if (enabledRules.length === 0) return currentRows;

    const nextRows = [...currentRows];
    const receiptRowIdx = nextRows.findIndex(r => r.row_type === 'RECEIPT');
    if (receiptRowIdx === -1) return currentRows;

    enabledRules.forEach(rule => {
      const sourceParticular = rule.sourceDisposalParticular || rule.targetDisposalParticular || '';
      if (!sourceParticular) return;

      const disposalRow = nextRows.find(r =>
        r.row_type === 'DISPOSAL' &&
        r.row_label.trim().toLowerCase() === sourceParticular.trim().toLowerCase()
      );

      if (disposalRow) {
        if (Array.isArray(rule.partitions) && rule.partitions.length > 0) {
          const recRow = { ...nextRows[receiptRowIdx], values: { ...nextRows[receiptRowIdx].values } };
          let changed = false;
          rule.partitions.forEach((part: any) => {
            const targetKey = part.targetReceiptProductKey || part.targetKey;
            const valStr = part.value !== undefined && part.value !== null ? String(part.value) : '';
            if (targetKey && recRow.values[targetKey] !== valStr) {
              recRow.values[targetKey] = valStr;
              changed = true;
            }
          });
          if (changed) {
            nextRows[receiptRowIdx] = recRow;
          }
        } else {
          const targetKey = rule.targetReceiptProductKey || rule.sourceProductKey || columns[0]?.key || '';
          if (!targetKey) return;
          const disposalRowTotal = Object.values(disposalRow.values).reduce(
            (sum, val) => sum + (parseFloat(val || '0') || 0), 0
          );

          const valStr = disposalRowTotal > 0 ? String(disposalRowTotal) : '';
          const recRow = { ...nextRows[receiptRowIdx], values: { ...nextRows[receiptRowIdx].values } };

          if (recRow.values[targetKey] !== valStr) {
            recRow.values[targetKey] = valStr;
            nextRows[receiptRowIdx] = recRow;
          }
        }
      }
    });

    return nextRows;
  };

  const openPartitionModal = (rowIdx: number, targetTab?: 'DAIRY_BREAKDOWN' | 'RECEIPTS_PARTITION') => {
    setActivePartitionRowIdx(rowIdx);
    const row = rows[rowIdx];
    if (!row) return;

    const rowLabel = row.row_label.trim();
    const isToOtherDairies = rowLabel.toLowerCase().includes('dairy') || rowLabel.toLowerCase().includes('dairies');

    if (targetTab) {
      setPartitionModalTab(targetTab);
    } else if (isToOtherDairies) {
      setPartitionModalTab('DAIRY_BREAKDOWN');
    } else {
      setPartitionModalTab('RECEIPTS_PARTITION');
    }

    // Load dairy breakdown items if present
    if (dairyBreakdowns[rowLabel] && dairyBreakdowns[rowLabel].length > 0) {
      setActiveDairyBreakdownItems([...dairyBreakdowns[rowLabel]]);
    } else {
      const defaultProdKey = columns.find(c => c.key === 'skim_milk') ? 'skim_milk' : (columns[0]?.key || '');
      const d1 = presetDairies[0] || 'Dairy 1';
      const d2 = presetDairies[1] || 'Dairy 2';
      setActiveDairyBreakdownItems([
        { dairy_name: d1, product_key: defaultProdKey, value: '' },
        { dairy_name: d2, product_key: defaultProdKey, value: '' },
      ]);
    }

    const existingRule = internalRules.find(
      r => r.sourceDisposalParticular?.trim().toLowerCase() === rowLabel.toLowerCase()
    );

    if (existingRule && Array.isArray(existingRule.partitions) && existingRule.partitions.length > 0) {
      setPartitionItems(
        existingRule.partitions.map((p: any) => ({
          targetKey: p.targetReceiptProductKey || p.targetKey || 'skim_milk',
          value: p.value !== undefined ? String(p.value) : '',
        }))
      );
    } else {
      const isProcessSplit = rowLabel.toLowerCase() === 'to process' || rowLabel.toLowerCase() === 'to partition';
      if (isProcessSplit) {
        setPartitionItems([
          { targetKey: 'skim_milk', value: '' },
          { targetKey: 'cream', value: '' },
        ]);
      } else {
        setPartitionItems([
          { targetKey: columns[0]?.key || 'skim_milk', value: '' },
        ]);
      }
    }
    setPartitionModalOpen(true);
  };

  const handleSavePartitions = async () => {
    if (activePartitionRowIdx === null) return;
    const row = rows[activePartitionRowIdx];
    if (!row) return;
    const rowLabel = row.row_label.trim();

    if (partitionModalTab === 'DAIRY_BREAKDOWN') {
      const validItems = activeDairyBreakdownItems.filter(
        b => b.dairy_name.trim() !== '' && b.value !== undefined && b.value !== ''
      );

      const updatedBreakdowns = {
        ...dairyBreakdowns,
        [rowLabel]: validItems,
      };
      setDairyBreakdowns(updatedBreakdowns);

      // Auto-populate cell values in Stock Entry row grid
      setRows(prev => {
        const next = [...prev];
        const targetRow = { ...next[activePartitionRowIdx], values: { ...next[activePartitionRowIdx].values } };
        const prodSums: Record<string, number> = {};
        validItems.forEach(b => {
          const valNum = parseFloat(b.value) || 0;
          prodSums[b.product_key] = (prodSums[b.product_key] || 0) + valNum;
        });
        Object.entries(prodSums).forEach(([pKey, sumVal]) => {
          targetRow.values[pKey] = sumVal > 0 ? String(sumVal) : '';
        });
        next[activePartitionRowIdx] = targetRow;
        return next;
      });

      setPartitionModalOpen(false);
      setSuccess(`Dairy destination breakdowns saved for "${rowLabel}"!`);
      setTimeout(() => setSuccess(''), 3000);
      return;
    }

    const formattedPartitions = partitionItems
      .filter(p => p.targetKey.trim() !== '')
      .map(p => ({
        targetReceiptProductKey: p.targetKey,
        targetReceiptProductLabel: columns.find(c => c.key === p.targetKey)?.label || p.targetKey,
        value: p.value,
      }));

    const existingRuleIdx = internalRules.findIndex(
      r => r.sourceDisposalParticular?.trim().toLowerCase() === rowLabel.toLowerCase()
    );

    let updatedRules: any[];
    if (existingRuleIdx !== -1) {
      updatedRules = [...internalRules];
      updatedRules[existingRuleIdx] = {
        ...updatedRules[existingRuleIdx],
        partitions: formattedPartitions,
        enabled: true,
      };
    } else {
      const newRule = {
        id: 'partition_map_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        sourceDisposalParticular: rowLabel,
        partitions: formattedPartitions,
        enabled: true,
      };
      updatedRules = [...internalRules, newRule];
    }

    setInternalRules(updatedRules);

    setRows(prev => {
      const next = [...prev];
      const receiptIdx = next.findIndex(r => r.row_type === 'RECEIPT');
      if (receiptIdx !== -1) {
        const recRow = { ...next[receiptIdx], values: { ...next[receiptIdx].values } };
        formattedPartitions.forEach(p => {
          if (p.targetReceiptProductKey && p.value !== undefined) {
            recRow.values[p.targetReceiptProductKey] = String(p.value);
          }
        });
        next[receiptIdx] = recRow;
      }
      return next;
    });

    try {
      await fetch('/api/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          report_type: 'INTERNAL_STOCK_MAPPING',
          notes: JSON.stringify(updatedRules),
        }),
      });
    } catch (err) {
      console.error('Failed saving partition mapping rules:', err);
    }

    setPartitionModalOpen(false);
    setSuccess(`Partitions applied to Receipts for "${rowLabel}"!`);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Load internal stock mappings (Receipts -> Disposals rules) on mount directly from DB
  useEffect(() => {
    async function loadInternalRules() {
      try {
        const res = await fetch('/api/entries?report_type=INTERNAL_STOCK_MAPPING');
        if (res.ok) {
          const json = await res.json();
          const entries: any[] = json.data || [];
          const entry = entries.find((e: any) => {
            if (!e.notes) return false;
            try {
              const parsed = JSON.parse(e.notes);
              return Array.isArray(parsed);
            } catch { return false; }
          }) || entries[0];

          if (entry && entry.notes) {
            try {
              const list = JSON.parse(entry.notes);
              if (Array.isArray(list)) setInternalRules(list);
            } catch (e) {
              console.error('Failed parsing internal stock mapping rules:', e);
            }
          }
        }
      } catch (err) {
        console.error('Failed loading internal stock mapping rules:', err);
      }
    }
    loadInternalRules();
  }, []);

  const setColumnsUnique = (newCols: Array<{ key: ColKey; label: string; full_name?: string; short_name?: string }> | ((prev: Array<{ key: ColKey; label: string; full_name?: string; short_name?: string }>) => Array<{ key: ColKey; label: string; full_name?: string; short_name?: string }>)) => {
    setColumns(prev => {
      const resolved = typeof newCols === 'function' ? newCols(prev) : newCols;
      const seen = new Set<string>();
      return resolved.filter(c => {
        if (seen.has(c.key)) return false;
        seen.add(c.key);
        return true;
      });
    });
  };

  // Load shifts & master products/particulars config on mount
  useEffect(() => {
    async function loadShiftConfig() {
      try {
        let masterProducts: any[] = [];
        let masterReceiptRows: any[] = [];
        let masterDisposalRows: any[] = [];

        // 1. ALWAYS load master products & particulars directly from database table via /api/stock/config
        try {
          const stockCfgRes = await fetch('/api/stock/config');
          if (stockCfgRes.ok) {
            const stockCfg = await stockCfgRes.json();
            if (Array.isArray(stockCfg.products) && stockCfg.products.length > 0) {
              masterProducts = stockCfg.products.map((p: any) => ({
                key: p.key || p.product_key,
                label: p.short_name || p.full_name || p.label || p.key,
                full_name: p.full_name || p.product_name,
                short_name: p.short_name || p.code,
                category: p.category || 'Standard',
              }));
            }
            if (Array.isArray(stockCfg.receipt_rows) && stockCfg.receipt_rows.length > 0) {
              masterReceiptRows = stockCfg.receipt_rows.map((r: any) => ({
                id: r.id,
                full_name: r.full_name || r.particular_name,
                short_name: r.short_name || r.code,
                label: r.full_name || r.short_name || r.particular_name,
              }));
            }
            if (Array.isArray(stockCfg.disposal_rows) && stockCfg.disposal_rows.length > 0) {
              masterDisposalRows = stockCfg.disposal_rows.map((d: any) => ({
                id: d.id,
                full_name: d.full_name || d.particular_name,
                short_name: d.short_name || d.code,
                label: d.full_name || d.short_name || d.particular_name,
              }));
            }
          }
        } catch (cfgErr) {
          console.error('Error fetching database stock config:', cfgErr);
        }



        setGlobalProducts(masterProducts);
        setColumnsUnique(masterProducts);
        setReceiptRowsConfig(masterReceiptRows);
        setDisposalRowsConfig(masterDisposalRows);

        // 2. Load shift schedule / mode preferences from app_settings
        const parsedShifts = shiftConfig?.shifts?.length ? shiftConfig.shifts : [
          { key: 'D', label: 'Day Shift', start: '06:00', end: '18:00' },
          { key: 'N', label: 'Night Shift', start: '18:00', end: '06:00' },
        ];
        const parsedMode: 'full_day' | 'shift' = shiftConfig?.mode || 'full_day';

        setShiftConfigs(parsedShifts);
        setReportMode(parsedMode);

        if (parsedMode === 'full_day') {
          setShift('F');
        } else if (!paramShift) {
          const now = new Date();
          const currentHours = now.getHours();
          const currentMinutes = now.getMinutes();
          const currentTimeVal = currentHours * 60 + currentMinutes;

          let detectedShift: Shift = 'D';
          for (const s of parsedShifts) {
            if (!s.start || !s.end) continue;
            const [startH, startM] = s.start.split(':').map(Number);
            const [endH, endM] = s.end.split(':').map(Number);
            const startVal = startH * 60 + startM;
            const endVal = endH * 60 + endM;

            if (startVal < endVal) {
              if (currentTimeVal >= startVal && currentTimeVal < endVal) {
                detectedShift = s.key as Shift;
                break;
              }
            } else {
              if (currentTimeVal >= startVal || currentTimeVal < endVal) {
                detectedShift = s.key as Shift;
                break;
              }
            }
          }
          setShift(detectedShift);
        }
      } catch (err) {
        console.error('Error loading shift configuration:', err);
      } finally {
        setConfigLoaded(true);
      }
    }
    loadShiftConfig();
  }, [shiftConfig]);

  useEffect(() => {
    if (shiftConfig) {
      if (shiftConfig.mode) setReportMode(shiftConfig.mode);
      if (Array.isArray(shiftConfig.shifts) && shiftConfig.shifts.length > 0) {
        setShiftConfigs(shiftConfig.shifts);
      }
    }
  }, [shiftConfig]);

  useEffect(() => {
    if (!configLoaded) return;
    if (!entryDate || !shift) return;
    setError('');
    setSuccess('');
    setObUnlocked(false);
    setReceiptsUnlocked(false);
    setDisposalsUnlocked(false);
    let active = true;

    async function loadData() {
      try {
        const activeProducts = globalProducts;

        // Helper to get previous shift/date
        const getPreviousShiftInfo = (): { date: string; shift: Shift } => {
          if (reportMode === 'shift' && shift === 'N') {
            return { date: entryDate, shift: 'D' };
          } else {
            const [year, month, day] = entryDate.split('-').map(Number);
            const prevDateObj = new Date(year, month - 1, day - 1);
            const yyyy = prevDateObj.getFullYear();
            const mm = String(prevDateObj.getMonth() + 1).padStart(2, '0');
            const dd = String(prevDateObj.getDate()).padStart(2, '0');
            const prevDateStr = `${yyyy}-${mm}-${dd}`;
            return { date: prevDateStr, shift: reportMode === 'shift' ? 'N' : 'F' };
          }
        };

        // Helper to compute Closing Balance from rows
        const calcClosingBalanceFromRows = (dbRows: any[], cols: any[], prevCustomValues: any = {}): Record<string, string> => {
          const effectiveDbRows: any[] = [];
          (dbRows || []).forEach((r: any) => {
            const entryJson = typeof r.entry_json === 'string' ? JSON.parse(r.entry_json) : (r.entry_json || {});
            const isSectionParent = ['Opening Balance', 'Receipts', 'Disposals'].includes(r.row_label) && Array.isArray(entryJson?.rows);
            if (isSectionParent && entryJson.rows.length > 0) {
              entryJson.rows.forEach((inner: any, iIdx: number) => {
                effectiveDbRows.push({
                  id: `${r.id}_${iIdx}`,
                  entry_id: r.entry_id,
                  row_type: inner.row_type || r.row_type,
                  row_label: inner.row_label || r.row_label,
                  values: inner.values || {},
                  sort_order: inner.sort_order ?? (r.sort_order * 100 + iIdx),
                  ...(inner.values || {}),
                });
              });
            } else {
              effectiveDbRows.push(r);
            }
          });

          const obSum: Record<string, number> = {};
          const recSum: Record<string, number> = {};
          const dispSum: Record<string, number> = {};

          cols.forEach(col => {
            const targetNorm = col.key.toLowerCase().replace(/[^a-z0-9]/g, '');
            if (targetNorm) {
              obSum[targetNorm] = 0;
              recSum[targetNorm] = 0;
              dispSum[targetNorm] = 0;
            }
          });

          effectiveDbRows.forEach((r: any) => {
            const label = (r.row_label || '').trim();
            const rowVals = prevCustomValues[label] || prevCustomValues[r.row_label];

            cols.forEach(col => {
              const targetNorm = col.key.toLowerCase().replace(/[^a-z0-9]/g, '');
              if (!targetNorm) return;

              let val = 0;
              const normKey = col.key.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
              const direct = r.values?.[col.key] ?? r.values?.[normKey] ?? r[col.key] ?? r[normKey];
              if (direct !== undefined && direct !== null && direct !== '') {
                const num = parseFloat(String(direct));
                if (!isNaN(num)) val = num;
              }

              if (val === 0 && targetNorm) {
                const searchSource = r.values && Object.keys(r.values).length > 0 ? { ...r, ...r.values } : r;
                for (const [rk, rv] of Object.entries(searchSource)) {
                  if (rv === undefined || rv === null || rv === '' || typeof rv === 'object') continue;
                  if (rk.toLowerCase().replace(/[^a-z0-9]/g, '') === targetNorm) {
                    const num = parseFloat(String(rv));
                    if (!isNaN(num)) {
                      val = num;
                      if (num !== 0) break;
                    }
                  }
                }
              }

              if (val === 0 && rowVals && targetNorm) {
                for (const [ck, cv] of Object.entries(rowVals)) {
                  if (cv === undefined || cv === null || cv === '' || typeof cv === 'object') continue;
                  if (ck.toLowerCase().replace(/[^a-z0-9]/g, '') === targetNorm) {
                    const num = parseFloat(String(cv));
                    if (!isNaN(num)) {
                      val = num;
                      if (num !== 0) break;
                    }
                  }
                }
              }

              if (r.row_type === 'OB') {
                obSum[targetNorm] = (obSum[targetNorm] || 0) + val;
              } else if (r.row_type === 'RECEIPT') {
                recSum[targetNorm] = (recSum[targetNorm] || 0) + val;
              } else if (r.row_type === 'DISPOSAL') {
                dispSum[targetNorm] = (dispSum[targetNorm] || 0) + val;
              }
            });
          });

          const cb: Record<string, string> = {};
          cols.forEach(col => {
            const targetNorm = col.key.toLowerCase().replace(/[^a-z0-9]/g, '');
            const val = (obSum[targetNorm] || 0) + (recSum[targetNorm] || 0) - (dispSum[targetNorm] || 0);
            const valStr = val === 0 ? '' : String(Math.round((val + Number.EPSILON) * 1000) / 1000);

            const normKey = col.key.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
            cb[col.key] = valStr;
            if (col.key !== normKey) {
              cb[normKey] = valStr;
            }
          });
          return cb;
        };


        const res = await fetch(`/api/stock?date=${entryDate}&shift=${shift}`);

        if (!res.ok) {
          if (active) {
            const fetchPrevShiftCB = async () => {
              let initialObValues: Record<string, string> = {};
              let finalCols = [...activeProducts];
              try {
                const prevInfo = getPreviousShiftInfo();
                let prevRes = await fetch(`/api/stock?date=${prevInfo.date}&shift=${prevInfo.shift}`);
                if (!prevRes.ok) {
                  prevRes = await fetch(`/api/stock?date=${prevInfo.date}`);
                }
                if (prevRes.ok) {
                  const prevJson = await prevRes.json();
                  const prevEntry = prevJson.data?.entries?.[0];
                  const prevRows = prevJson.data?.stock_rows || [];

                  let prevCustomCols: Array<{ key: ColKey; label: string }> = [];
                  let prevCustomVals: Record<string, Record<ColKey, string>> = {};
                  if (prevEntry && prevEntry.notes) {
                    const notesParts = prevEntry.notes.split('\n');
                    notesParts.forEach((part: string) => {
                      if (part.includes('__METADATA__:')) {
                        const [, metaJson] = part.split('__METADATA__:');
                        try {
                          const meta = JSON.parse(metaJson);
                          if (meta.custom_columns) prevCustomCols = meta.custom_columns;
                          if (meta.custom_values) prevCustomVals = meta.custom_values;
                        } catch { }
                      }
                    });
                  }

                  prevCustomCols.forEach((cc: any) => {
                    if (!finalCols.some(col => col.key === cc.key || col.key.replace(/\./g, '_') === cc.key.replace(/\./g, '_'))) {
                      finalCols.push(cc);
                    }
                  });

                  initialObValues = calcClosingBalanceFromRows(prevRows, finalCols, prevCustomVals);
                }
              } catch (err) {
                console.error('Error fetching previous shift closing balance:', err);
              }

              if (active) {
                let initialRows = makeDefaultRows(receiptRowsConfig, disposalRowsConfig);
                try {
                  const tmplRes = await fetch('/api/stock/templates');
                  if (tmplRes.ok) {
                    const tmplJson = await tmplRes.json();
                    const defMaster = (tmplJson.masters || []).find((m: any) => m.is_default) || tmplJson.masters?.[0];
                    const savedTmpl = defMaster ? tmplJson.templates?.[defMaster.key] : null;
                    if (savedTmpl && Array.isArray(savedTmpl.rows) && savedTmpl.rows.length > 0) {
                      initialRows = savedTmpl.rows.map((r: any) => ({
                        row_type: r.row_type,
                        row_label: r.row_label,
                        values: { ...r.values },
                      }));
                      if (Array.isArray(savedTmpl.product_columns) && savedTmpl.product_columns.length > 0) {
                        finalCols = savedTmpl.product_columns;
                      }
                    }
                  }
                } catch (tErr) {
                  console.warn('Could not load custom stock master template, using standard defaults:', tErr);
                }

                setColumnsUnique(finalCols);
                if (initialRows.length > 0) {
                  initialRows[0].values = { ...initialRows[0].values, ...initialObValues };
                }
                setRows(initialRows);
                setNotes('');
                await syncFromPreparationCharts();
              }
            };

            fetchPrevShiftCB();
          }
          return;
        }

        const json = await res.json();
        const entry = json.data?.entries?.[0];
        if (!entry) return;

        if (active) {
          let parsedCols = activeProducts ? [...activeProducts] : [];

          let customVals: Record<string, Record<string, string>> = {};
          let cleanNotes = entry.notes || '';

          const notesParts = (entry.notes || '').split('\n');
          notesParts.forEach((part: string) => {
            if (part.includes('__METADATA__:') || part.includes('__METADATA__::')) {
              const [, metaJson] = part.split('__METADATA__:');
              try {
                const meta = JSON.parse(metaJson);
                if (meta.custom_columns) {
                  meta.custom_columns.forEach((cc: any) => {
                    if (!parsedCols.some(col => col.key === cc.key)) {
                      parsedCols.push(cc);
                    }
                  });
                }
                if (meta.custom_values) {
                  customVals = meta.custom_values;
                }
              } catch (e) {
                console.error('Failed to parse metadata:', e);
              }
            }
          });

          cleanNotes = notesParts
            .filter((part: string) => !part.includes('__METADATA__:') && !part.includes('__STOCK_SUMMARY__:'))
            .join('\n')
            .trim();

          setColumnsUnique(parsedCols);
          setNotes(cleanNotes);

          const rawDbRows = [...(json.data.stock_rows || [])].sort((a: any, b: any) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
          const sortedDbRows: any[] = [];
          rawDbRows.forEach((r: any) => {
            const entryJson = typeof r.entry_json === 'string' ? JSON.parse(r.entry_json) : (r.entry_json || {});
            const isSectionParent = ['Opening Balance', 'Receipts', 'Disposals'].includes(r.row_label) && Array.isArray(entryJson?.rows);
            if (isSectionParent && entryJson.rows.length > 0) {
              entryJson.rows.forEach((inner: any, iIdx: number) => {
                sortedDbRows.push({
                  id: `${r.id}_${iIdx}`,
                  entry_id: r.entry_id,
                  row_type: inner.row_type || r.row_type,
                  row_label: inner.row_label || r.row_label,
                  values: inner.values || {},
                  sort_order: inner.sort_order ?? (r.sort_order * 100 + iIdx),
                  ...(inner.values || {}),
                });
              });
            } else {
              sortedDbRows.push(r);
            }
          });

          // Base template contains OB, Receipts, and Disposals
          const loadedRows = makeDefaultRows(receiptRowsConfig, disposalRowsConfig);

          if (sortedDbRows.length > 0) {
            sortedDbRows.forEach((dbRow: any) => {
              const dbRowType = dbRow.row_type as StockRowState['row_type'];
              const dbRowLabel = (dbRow.row_label || '').trim();
              const customValsRow = customVals[dbRowLabel] || customVals[dbRow.row_label];

              const values: Record<string, string> = {};
              parsedCols.forEach(col => {
                const normKey = col.key.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
                const targetNorm = col.key.toLowerCase().replace(/[^a-z0-9]/g, '');

                let foundVal = '';

                // Direct exact lookup first (checking dbRow.values, then dbRow root properties)
                const directVal = dbRow.values?.[col.key] ?? dbRow.values?.[normKey] ?? dbRow[col.key] ?? dbRow[normKey];
                if (directVal !== undefined && directVal !== null && directVal !== '') {
                  const numVal = typeof directVal === 'number' ? directVal : parseFloat(String(directVal));
                  if (!isNaN(numVal) && numVal !== 0) {
                    foundVal = String(numVal);
                  }
                }

                // Generic alphanumeric normalized lookup
                if (!foundVal && targetNorm) {
                  const searchSource = dbRow.values && Object.keys(dbRow.values).length > 0 ? { ...dbRow, ...dbRow.values } : dbRow;
                  for (const [rk, rv] of Object.entries(searchSource)) {
                    if (rv === undefined || rv === null || rv === '' || typeof rv === 'object') continue;
                    if (rk.toLowerCase().replace(/[^a-z0-9]/g, '') === targetNorm) {
                      const numVal = typeof rv === 'number' ? rv : parseFloat(String(rv));
                      if (!isNaN(numVal) && numVal !== 0) {
                        foundVal = String(numVal);
                        break;
                      }
                    }
                  }
                }

                // Custom metadata fallback check
                if (!foundVal && customValsRow && targetNorm) {
                  for (const [ck, cv] of Object.entries(customValsRow)) {
                    if (cv === undefined || cv === null || cv === '' || typeof cv === 'object') continue;
                    if (ck.toLowerCase().replace(/[^a-z0-9]/g, '') === targetNorm) {
                      const numVal = typeof cv === 'number' ? cv : parseFloat(String(cv));
                      if (!isNaN(numVal) && numVal !== 0) {
                        foundVal = String(numVal);
                        break;
                      }
                    }
                  }
                }

                if (foundVal) {
                  values[col.key] = foundVal;
                }
              });

              // Merge any remaining explicit properties from dbRow.values avoiding dot duplicates
              if (dbRow.values && typeof dbRow.values === 'object') {
                Object.entries(dbRow.values).forEach(([colKey, val]) => {
                  if (val !== undefined && val !== null && val !== '' && typeof val !== 'object') {
                    const normK = colKey.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
                    if (values[colKey] === undefined && values[normK] === undefined) {
                      values[normK] = String(val);
                    }
                  }
                });
              }

              if (customValsRow) {
                Object.entries(customValsRow).forEach(([colKey, val]) => {
                  if (val !== undefined && val !== null && val !== '') {
                    values[colKey] = String(val);
                  }
                });
              }

              if (dbRowType === 'OB') {
                const obIdx = loadedRows.findIndex(r => r.row_type === 'OB');
                if (obIdx !== -1) {
                  loadedRows[obIdx].values = {
                    ...loadedRows[obIdx].values,
                    ...values,
                  };
                } else {
                  loadedRows[0].values = {
                    ...loadedRows[0].values,
                    ...values,
                  };
                }
              } else {
                const normDbLabel = dbRowLabel.toLowerCase().replace(/[^a-z0-9]/g, '');
                const existingIdx = loadedRows.findIndex(r =>
                  r.row_type === dbRowType && (
                    r.row_label.trim().toLowerCase() === dbRowLabel.toLowerCase() ||
                    (normDbLabel && r.row_label.toLowerCase().replace(/[^a-z0-9]/g, '') === normDbLabel)
                  )
                );

                if (existingIdx !== -1) {
                  loadedRows[existingIdx].values = {
                    ...loadedRows[existingIdx].values,
                    ...values,
                  };
                } else {
                  let insertIdx = -1;
                  for (let i = loadedRows.length - 1; i >= 0; i--) {
                    if (loadedRows[i].row_type === dbRowType) {
                      insertIdx = i;
                      break;
                    }
                  }
                  const newRow: StockRowState = {
                    row_type: dbRowType,
                    row_label: dbRow.row_label,
                    values,
                  };
                  if (insertIdx !== -1) {
                    loadedRows.splice(insertIdx + 1, 0, newRow);
                  } else {
                    loadedRows.push(newRow);
                  }
                }
              }
            });
          }


          // Fallback: If loaded OB row has no non-zero values, populate from previous shift/day closing balance
          const hasObValues = Object.values(loadedRows[0].values).some(v => v !== undefined && v !== null && v !== '' && parseFloat(v) !== 0);
          if (!hasObValues) {
            try {
              const getPrevInfo = (): { date: string; shift: Shift } => {
                if (reportMode === 'shift' && shift === 'N') {
                  return { date: entryDate, shift: 'D' };
                } else {
                  const [year, month, day] = entryDate.split('-').map(Number);
                  const prevDateObj = new Date(year, month - 1, day - 1);
                  const yyyy = prevDateObj.getFullYear();
                  const mm = String(prevDateObj.getMonth() + 1).padStart(2, '0');
                  const dd = String(prevDateObj.getDate()).padStart(2, '0');
                  const prevDateStr = `${yyyy}-${mm}-${dd}`;
                  return { date: prevDateStr, shift: reportMode === 'shift' ? 'N' : 'F' };
                }
              };
              const prevInfo = getPrevInfo();
              let prevRes = await fetch(`/api/stock?date=${prevInfo.date}&shift=${prevInfo.shift}`);
              if (!prevRes.ok) {
                prevRes = await fetch(`/api/stock?date=${prevInfo.date}`);
              }
              if (prevRes.ok) {
                const prevJson = await prevRes.json();
                const prevRows = prevJson.data?.stock_rows || [];
                let prevCustomVals: Record<string, Record<ColKey, string>> = {};
                const prevEntry = prevJson.data?.entries?.[0];
                if (prevEntry && prevEntry.notes) {
                  const notesParts = prevEntry.notes.split('\n');
                  notesParts.forEach((part: string) => {
                    if (part.includes('__METADATA__:')) {
                      const [, metaJson] = part.split('__METADATA__:');
                      try {
                        const meta = JSON.parse(metaJson);
                        if (meta.custom_values) prevCustomVals = meta.custom_values;
                      } catch { }
                    }
                  });
                }
                const prevObValues = calcClosingBalanceFromRows(prevRows, parsedCols, prevCustomVals);
                loadedRows[0].values = { ...prevObValues, ...loadedRows[0].values };
              }
            } catch (prevErr) {
              console.error('Error fetching fallback OB for existing entry:', prevErr);
            }
          }

          setRows(loadedRows);
        }
      } catch (err) {
        console.error('Error loading existing stock data:', err);
      }
    }

    loadData();
    return () => { active = false; };
  }, [entryDate, shift, configLoaded, globalProducts, receiptRowsConfig, disposalRowsConfig, reportMode]);

  const updateCell = (rowIdx: number, col: ColKey, val: string) => {
    setRows(prev => {
      const next = [...prev];
      next[rowIdx] = { ...next[rowIdx], values: { ...next[rowIdx].values, [col]: val } };
      return next;
    });
  };

  const addRowAfter = (row_type: StockRowState['row_type'], idx: number) => {
    setRows(prev => {
      const next = [...prev];
      const newItem: StockRowState = {
        row_type,
        row_label: '',
        values: {},
      };
      if (idx !== -1) {
        next.splice(idx + 1, 0, newItem);
      } else {
        let insertAt = -1;
        for (let i = prev.length - 1; i >= 0; i--) {
          if (prev[i].row_type === row_type) {
            insertAt = i;
            break;
          }
        }
        if (insertAt !== -1) {
          next.splice(insertAt + 1, 0, newItem);
        } else {
          next.push(newItem);
        }
      }
      return next;
    });
  };

  const deleteRow = async (idx: number) => {
    const item = rows[idx];
    if (!item) return;
    const hasData = Object.values(item.values).some(v => v && parseFloat(v) !== 0);
    if (hasData || item.row_label.trim() !== '') {
      const ok = await confirm({
        title: 'Confirm Row Removal',
        message: 'Are you sure you want to remove this row containing data?',
        confirmText: 'Remove Row',
        cancelText: 'Cancel',
        type: 'warning',
      });
      if (!ok) return;
    }
    setRows(prev => {
      const next = [...prev];
      next.splice(idx, 1);
      return next;
    });
  };

  const addColumnAfter = (colKey: string) => {
    const label = window.prompt("Enter new column header name:");
    if (!label || label.trim() === '') return;

    const newKey = 'custom_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5);
    setColumnsUnique(prev => {
      const idx = prev.findIndex(c => c.key === colKey);
      const next = [...prev];
      if (idx === -1) {
        next.push({ key: newKey, label: label.trim() });
      } else {
        next.splice(idx + 1, 0, { key: newKey, label: label.trim() });
      }
      return next;
    });
  };

  const deleteColumn = async (colKey: string) => {
    const hasData = rows.some(r => r.values[colKey] && parseFloat(r.values[colKey]) !== 0);
    if (hasData) {
      const ok = await confirm({
        title: 'Confirm Column Removal',
        message: 'Are you sure you want to remove this column and all its data?',
        confirmText: 'Remove Column',
        cancelText: 'Cancel',
        type: 'warning',
      });
      if (!ok) return;
    }

    setColumnsUnique(prev => prev.filter(c => c.key !== colKey));
    setRows(prev => prev.map(r => {
      const nextValues = { ...r.values };
      delete nextValues[colKey];
      return { ...r, values: nextValues };
    }));
  };

  const autoCompileSTGFromStock = async (
    targetDate: string,
    targetShift: Shift | null,
    stockCols: Array<{ key: string; label: string; full_name?: string; short_name?: string }>,
    stockRowsState: StockRowState[]
  ) => {
    // 1. Load active custom mapping rules if present in database
    let mappingRules: any[] = [];
    try {
      const mapRes = await fetch('/api/entries?report_type=STOCK_MAPPING');
      if (mapRes.ok) {
        const mapJson = await mapRes.json();
        const mapEntry = mapJson.data?.[0];
        if (mapEntry && mapEntry.notes) {
          const list = JSON.parse(mapEntry.notes);
          if (Array.isArray(list) && list.length > 0) mappingRules = list;
        }
      }
    } catch (e) {
      console.error('Failed loading STOCK_MAPPING rules for autoCompile:', e);
    }

    const blocksData: Record<string, {
      label: string;
      ob: any;
      receipts: any[];
      disposals: any[];
      cb: any;
    }> = {};

    const customStatements: Array<{ key: string; label: string }> = [];
    const enabledBlockKeys: string[] = [];

    const getBlockInfo = (col: { key: string; label: string; full_name?: string; short_name?: string }) => {
      const cleanKey = col.key.toLowerCase().trim();
      const rawFullName = (col.full_name || col.short_name || col.label || col.key).trim();
      const fullNameUpper = rawFullName.toUpperCase();

      let blockKey = cleanKey.toUpperCase();
      if (cleanKey === 'wh_milk') blockKey = 'WM';
      else if (cleanKey === 'skim_milk') blockKey = 'SSM';
      else if (cleanKey === 'cream') blockKey = 'CREAM';
      else if (cleanKey === 'smp') blockKey = 'SMP';

      let blockLabel = `${fullNameUpper} STATEMENT`;
      if (blockKey === 'WM') {
        blockLabel = `${fullNameUpper} - RECEIPT AND DISPOSAL STATEMENT`;
      }

      const isSMP = blockKey === 'SMP' || fullNameUpper.includes('SMP') || fullNameUpper.includes('POWDER');

      return { blockKey, blockLabel, isSMP };
    };

    // If explicit custom mapping rules exist, process them
    if (mappingRules.length > 0) {
      const normalizeStr = (str: string) => (str || '').toLowerCase().replace(/[:\s]+/g, ' ').trim();
      mappingRules.forEach(rule => {
        const { stockProductKey, stockSection, stockParticular, stgBlockKey, stgBlockLabel, stgSection, stgItemName, stgTargetField } = rule;
        const normProductKey = normalizeStr(stockProductKey);
        const col = stockCols.find(c =>
          c.key.toLowerCase() === stockProductKey.toLowerCase() ||
          normalizeStr(c.key) === normProductKey ||
          normalizeStr(c.label) === normProductKey
        );

        const normParticular = normalizeStr(stockParticular);
        const stockRow = stockRowsState.find(r => {
          if (r.row_type !== stockSection) return false;
          const normLabel = normalizeStr(r.row_label);
          return normLabel === normParticular || normLabel.includes(normParticular) || normParticular.includes(normLabel);
        });

        if (!stockRow && stockSection !== 'CB') return;

        let valNum = 0;
        if (stockSection === 'CB') {
          const targetKey = col?.key || stockProductKey;
          const obVal = getSectionSum('OB', targetKey);
          const recVal = getSectionSum('RECEIPT', targetKey);
          const dispVal = getSectionSum('DISPOSAL', targetKey);
          valNum = obVal + recVal - dispVal;
        } else if (stockRow) {
          const cleanKey = stockProductKey.toLowerCase().replace(/[^a-z0-9]/g, '');
          const aliases: Record<string, string[]> = {
            whmilk: ['wm', 'wh_milk', 'wh.milk'],
            wh_milk: ['wm', 'whmilk', 'wh.milk'],
            'wh.milk': ['wm', 'whmilk', 'wh_milk'],
            wm: ['whmilk', 'wh_milk', 'wh.milk'],
            ssm: ['skimmilk', 'skim_milk', 'skim.milk'],
            cream: ['crm', 'cream'],
            smp: ['smp', 'skimmedmilkpowder', 'milkpowder'],
          };
          const altKeys = aliases[cleanKey] || aliases[stockProductKey.toLowerCase()] || [];
          const candidates = [stockProductKey, col?.key || '', cleanKey, ...altKeys].filter(Boolean);

          for (const cand of candidates) {
            const candClean = cand.toLowerCase().replace(/[^a-z0-9]/g, '');
            if (stockRow.values && typeof stockRow.values === 'object') {
              if (stockRow.values[cand] !== undefined && stockRow.values[cand] !== '') {
                const parsed = parseFloat(String(stockRow.values[cand]));
                if (!isNaN(parsed) && parsed !== 0) { valNum = parsed; break; }
              }
              for (const [vk, vv] of Object.entries(stockRow.values)) {
                if (vk.toLowerCase().replace(/[^a-z0-9]/g, '') === candClean) {
                  const parsed = parseFloat(String(vv));
                  if (!isNaN(parsed) && parsed !== 0) { valNum = parsed; break; }
                }
              }
              if (valNum !== 0) break;
            }
            if ((stockRow as any)[cand] !== undefined && (stockRow as any)[cand] !== '') {
              const parsed = parseFloat(String((stockRow as any)[cand]));
              if (!isNaN(parsed) && parsed !== 0) { valNum = parsed; break; }
            }
          }
        }
        if (!valNum || isNaN(valNum)) return;

        if (!blocksData[stgBlockKey]) {
          blocksData[stgBlockKey] = {
            label: stgBlockLabel || `${stgBlockKey} STATEMENT`,
            ob: { item_name: 'OB', qty_lts: '', qty_kg: '', fat_pct: '', snf_pct: '', sp_gr: '1.0285', kg_fat: '', kg_snf: '' },
            receipts: [],
            disposals: [],
            cb: { item_name: 'CB', qty_lts: '', qty_kg: '', fat_pct: '', snf_pct: '', sp_gr: '', kg_fat: '', kg_snf: '' },
          };
        }

        if (!enabledBlockKeys.includes(stgBlockKey)) {
          enabledBlockKeys.push(stgBlockKey);
          customStatements.push({ key: stgBlockKey, label: stgBlockLabel || `${stgBlockKey} Statement` });
        }

        const b = blocksData[stgBlockKey];
        const isSMP = stgBlockKey === 'SMP' || (stgBlockLabel || '').toUpperCase().includes('SMP');
        const fieldKey = stgTargetField || (isSMP ? 'qty_kg' : 'qty_lts');

        const assignVal = (targetObj: any) => {
          targetObj[fieldKey] = String(valNum);
          if (fieldKey === 'qty_lts' && !isSMP) {
            targetObj.qty_kg = (valNum * 1.0285).toFixed(3);
            targetObj.sp_gr = '1.0285';
          } else if (fieldKey === 'qty_kg' && isSMP) {
            targetObj.qty_lts = '';
          }
        };

        if (stgSection === 'OB') {
          assignVal(b.ob);
        } else if (stgSection === 'CB') {
          assignVal(b.cb);
        } else {
          const list = stgSection === 'RECEIPT' ? b.receipts : b.disposals;
          let existing = list.find(r => normalizeStr(r.item_name) === normalizeStr(stgItemName));
          if (!existing) {
            existing = { item_name: stgItemName, qty_lts: '', qty_kg: '', fat_pct: '', snf_pct: '', sp_gr: isSMP ? '' : '1.0285', kg_fat: '', kg_snf: '' };
            list.push(existing);
          }
          assignVal(existing);
        }
      });
    }

    // Dynamic Automatic Generator: Iterate through ALL stock columns and build STG statement blocks automatically
    stockCols.forEach(col => {
      const { blockKey, blockLabel, isSMP } = getBlockInfo(col);

      // 1. Get OB value
      const obRow = stockRowsState.find(r => r.row_type === 'OB');
      const obVal = obRow && obRow.values[col.key] ? parseFloat(obRow.values[col.key] || '0') || 0 : 0;

      // 2. Get Receipt rows
      const receiptRows = stockRowsState.filter(r => r.row_type === 'RECEIPT');
      const activeReceipts: Array<{ item_name: string; val: number }> = [];
      receiptRows.forEach(r => {
        const val = parseFloat(r.values[col.key] || '0') || 0;
        if (val > 0) {
          activeReceipts.push({ item_name: r.row_label.trim() || 'Receipt', val });
        }
      });

      // 3. Get Disposal rows
      const disposalRows = stockRowsState.filter(r => r.row_type === 'DISPOSAL');
      const activeDisposals: Array<{ item_name: string; val: number }> = [];
      disposalRows.forEach(r => {
        const val = parseFloat(r.values[col.key] || '0') || 0;
        if (val > 0) {
          activeDisposals.push({ item_name: r.row_label.trim() || 'Disposal', val });
        }
      });

      // If column has OB, Receipts, or Disposals, create/update statement block
      if (obVal > 0 || activeReceipts.length > 0 || activeDisposals.length > 0) {
        if (!enabledBlockKeys.includes(blockKey)) {
          enabledBlockKeys.push(blockKey);
          customStatements.push({ key: blockKey, label: blockLabel });
        }

        if (!blocksData[blockKey]) {
          const bOb = {
            item_name: 'OB',
            qty_lts: !isSMP && obVal > 0 ? String(obVal) : '',
            qty_kg: isSMP && obVal > 0 ? String(obVal) : (!isSMP && obVal > 0 ? (obVal * 1.0285).toFixed(3) : ''),
            fat_pct: '',
            snf_pct: '',
            sp_gr: !isSMP && obVal > 0 ? '1.0285' : '',
            kg_fat: '',
            kg_snf: '',
          };

          const bReceipts = activeReceipts.map(r => ({
            item_name: r.item_name,
            qty_lts: !isSMP ? String(r.val) : '',
            qty_kg: isSMP ? String(r.val) : (r.val * 1.0285).toFixed(3),
            fat_pct: '',
            snf_pct: '',
            sp_gr: !isSMP ? '1.0285' : '',
            kg_fat: '',
            kg_snf: '',
          }));

          const bDisposals = activeDisposals.map(d => ({
            item_name: d.item_name,
            qty_lts: !isSMP ? String(d.val) : '',
            qty_kg: isSMP ? String(d.val) : (d.val * 1.0285).toFixed(3),
            fat_pct: '',
            snf_pct: '',
            sp_gr: !isSMP ? '1.0285' : '',
            kg_fat: '',
            kg_snf: '',
          }));

          blocksData[blockKey] = {
            label: blockLabel,
            ob: bOb,
            receipts: bReceipts,
            disposals: bDisposals,
            cb: { item_name: 'CB', qty_lts: '', qty_kg: '', fat_pct: '', snf_pct: '', sp_gr: '', kg_fat: '', kg_snf: '' },
          };
        }
      }
    });

    if (enabledBlockKeys.length === 0) return;

    // Build database stg_rows & customBlocksState
    const stg_rows: any[] = [];
    const customBlocksState: Record<string, any> = {};

    Object.entries(blocksData).forEach(([bKey, b]) => {
      const obLts = parseFloat(b.ob.qty_lts) || 0;
      const obKg = parseFloat(b.ob.qty_kg) || 0;

      let receiptsLtsTotal = 0;
      let receiptsKgTotal = 0;
      b.receipts.forEach((r: any) => {
        receiptsLtsTotal += parseFloat(r.qty_lts) || 0;
        receiptsKgTotal += parseFloat(r.qty_kg) || 0;
      });

      let disposalsLtsTotal = 0;
      let disposalsKgTotal = 0;
      b.disposals.forEach((d: any) => {
        disposalsLtsTotal += parseFloat(d.qty_lts) || 0;
        disposalsKgTotal += parseFloat(d.qty_kg) || 0;
      });

      const cbLts = obLts + receiptsLtsTotal - disposalsLtsTotal;
      const cbKg = obKg + receiptsKgTotal - disposalsKgTotal;

      b.cb.qty_lts = cbLts > 0 ? String(cbLts) : '';
      b.cb.qty_kg = cbKg > 0 ? cbKg.toFixed(3) : '';

      stg_rows.push({
        product_block: bKey,
        side: 'RECEIPT',
        item_name: 'OB',
        qty_lts: obLts,
        qty_kg: obKg,
        fat_pct: parseFloat(b.ob.fat_pct) || 0,
        snf_pct: parseFloat(b.ob.snf_pct) || 0,
        sp_gr: parseFloat(b.ob.sp_gr) || 1.0285,
        kg_fat: parseFloat(b.ob.kg_fat) || 0,
        kg_snf: parseFloat(b.ob.kg_snf) || 0,
        sort_order: 0,
      });

      b.receipts.forEach((r: any, idx: number) => {
        stg_rows.push({
          product_block: bKey,
          side: 'RECEIPT',
          item_name: r.item_name,
          qty_lts: parseFloat(r.qty_lts) || 0,
          qty_kg: parseFloat(r.qty_kg) || 0,
          fat_pct: parseFloat(r.fat_pct) || 0,
          snf_pct: parseFloat(r.snf_pct) || 0,
          sp_gr: parseFloat(r.sp_gr) || 1.0285,
          kg_fat: parseFloat(r.kg_fat) || 0,
          kg_snf: parseFloat(r.kg_snf) || 0,
          sort_order: idx + 1,
        });
      });

      b.disposals.forEach((d: any, idx: number) => {
        stg_rows.push({
          product_block: bKey,
          side: 'DISPOSAL',
          item_name: d.item_name,
          qty_lts: parseFloat(d.qty_lts) || 0,
          qty_kg: parseFloat(d.qty_kg) || 0,
          fat_pct: parseFloat(d.fat_pct) || 0,
          snf_pct: parseFloat(d.snf_pct) || 0,
          sp_gr: parseFloat(d.sp_gr) || 1.0285,
          kg_fat: parseFloat(d.kg_fat) || 0,
          kg_snf: parseFloat(d.kg_snf) || 0,
          sort_order: idx + 1,
        });
      });

      stg_rows.push({
        product_block: bKey,
        side: 'DISPOSAL',
        item_name: 'CB',
        qty_lts: cbLts > 0 ? cbLts : 0,
        qty_kg: cbKg > 0 ? Number(cbKg.toFixed(3)) : 0,
        fat_pct: parseFloat(b.cb.fat_pct) || 0,
        snf_pct: parseFloat(b.cb.snf_pct) || 0,
        sp_gr: parseFloat(b.cb.sp_gr) || 1.0285,
        kg_fat: parseFloat(b.cb.kg_fat) || 0,
        kg_snf: parseFloat(b.cb.kg_snf) || 0,
        sort_order: 99,
      });

      customBlocksState[bKey] = {
        opening_balance: b.ob,
        receipts: b.receipts,
        disposals: b.disposals,
        physical_count: b.cb,
      };
    });

    // Save TS entry via POST /api/entries
    const userNotesText = notes
      ? notes
          .split('\n')
          .filter(p => !p.includes('__METADATA__:') && !p.includes('__STOCK_SUMMARY__:'))
          .join('\n')
          .trim()
      : '';
    const tsMeta = {
      custom_statements: customStatements,
      custom_blocks: customBlocksState,
      enabled_blocks: enabledBlockKeys,
    };
    const tsNotes = (userNotesText ? userNotesText + '\n' : '') + '__METADATA__:' + JSON.stringify(tsMeta);

    const tsEntryRes = await fetch('/api/entries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        entry_date: targetDate,
        shift: targetShift,
        report_type: 'TS',
        notes: tsNotes,
      }),
    });

    if (tsEntryRes.ok) {
      const tsEntryJson = await tsEntryRes.json();
      const tsEntryId = tsEntryJson.data?.id;

      if (tsEntryId) {
        await fetch('/api/ts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            entry_id: tsEntryId,
            ts_rows: [],
            stg_rows,
          }),
        });
      }
    }
  };

  const handleSave = async (nextAction: 'view' | 'stay' | 'next') => {
    if (!entryDate) { setError('Please select a date.'); return; }
    setSaving(true); setError(''); setSuccess('');
    try {
      // 1. Extract custom columns and values metadata
      const DB_STOCK_ROW_COLS = new Set([
        'wh_milk', 'dlt_milk', 'fc_milk', 'std_milk', 'toned_curd', 'toned_milk',
        'dtm', 'skim_milk', 'cream', 'butter_milk', 'r_con', 'smp', 'water'
      ]);
      const customCols = columns.filter(c => {
        const norm = c.key.trim().toLowerCase().replace(/[\._\s]/g, '_');
        return (c as any).is_custom || !DB_STOCK_ROW_COLS.has(norm);
      });
      const customValues: Record<string, Record<string, string>> = {}; // row_label -> colKey -> val
      rows.forEach(r => {
        const vals: Record<string, string> = {};
        customCols.forEach(cc => {
          if (r.values[cc.key] !== undefined && r.values[cc.key] !== '') {
            vals[cc.key] = r.values[cc.key]!;
          }
        });
        if (Object.keys(vals).length > 0) {
          customValues[r.row_label] = vals;
        }
      });

      // 2. Compute Live Stock Summary Rows (JSON payload)
      const stockSummaryRows = [
        { summary_type: 'OB', row_label: 'Opening Balance', sort_order: 0, summary_data: {} as Record<string, number> },
        { summary_type: 'TOTAL_RECEIPT', row_label: 'Total Receipts (+)', sort_order: 1, summary_data: {} as Record<string, number> },
        { summary_type: 'TOTAL_DISPOSAL', row_label: 'Total Disposals (-)', sort_order: 2, summary_data: {} as Record<string, number> },
        { summary_type: 'CB', row_label: 'Closing Balance (=)', sort_order: 3, summary_data: {} as Record<string, number> },
      ];

      columns.forEach(col => {
        const normKey = col.key.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
        const obVal = getSectionSum('OB', col.key);
        const recVal = getSectionSum('RECEIPT', col.key);
        const dispVal = getSectionSum('DISPOSAL', col.key);

        stockSummaryRows[0].summary_data[col.key] = obVal;
        stockSummaryRows[0].summary_data[normKey] = obVal;

        stockSummaryRows[1].summary_data[col.key] = recVal;
        stockSummaryRows[1].summary_data[normKey] = recVal;

        stockSummaryRows[2].summary_data[col.key] = dispVal;
        stockSummaryRows[2].summary_data[normKey] = dispVal;

        stockSummaryRows[3].summary_data[col.key] = obVal + recVal - dispVal;
        stockSummaryRows[3].summary_data[normKey] = obVal + recVal - dispVal;
      });

      const userNotesText = notes
        ? notes
            .split('\n')
            .filter(p => !p.includes('__METADATA__:') && !p.includes('__STOCK_SUMMARY__:'))
            .join('\n')
            .trim()
        : '';
      const notesParts: string[] = [];
      if (userNotesText) notesParts.push(userNotesText);

      if (customCols.length > 0 || Object.keys(customValues).length > 0) {
        const metadata = {
          custom_columns: customCols,
          custom_values: customValues,
        };
        notesParts.push(`__METADATA__:${JSON.stringify(metadata)}`);
      }
      notesParts.push(`__STOCK_SUMMARY__:${JSON.stringify(stockSummaryRows)}`);
      const finalNotes = notesParts.join('\n');

      const entryRes = await fetch('/api/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entry_date: entryDate, shift, report_type: 'STOCK', notes: finalNotes }),
      });
      const entryData = await entryRes.json();
      if (!entryRes.ok) throw new Error(entryData.error || 'Failed to create entry');

      const entry_id = entryData.data.id;

      // Attach entry_id to summary rows for API post
      const summaryRowsWithId = stockSummaryRows.map(s => ({ ...s, entry_id }));

      // 3. Map ALL columns dynamically to stock rows
      const stockRows = rows.map((r, i) => {
        // Build clean normalized values object without duplicate dotted keys
        const cleanValues: Record<string, string> = {};
        if (r.values && typeof r.values === 'object') {
          Object.entries(r.values).forEach(([k, v]) => {
            const canonicalKey = k.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
            if (v !== undefined && v !== null && v !== '') {
              if (cleanValues[canonicalKey] === undefined || cleanValues[canonicalKey] === '0') {
                cleanValues[canonicalKey] = String(v);
              }
            }
          });
        }

        const rowObj: Record<string, any> = {
          row_type: r.row_type,
          row_label: r.row_label,
          sort_order: i,
          values: cleanValues,
        };

        columns.forEach(col => {
          const normKey = col.key.trim().replace(/\.+/g, '_').replace(/_+/g, '_').toLowerCase();
          const targetNorm = col.key.toLowerCase().replace(/[^a-z0-9]/g, '');

          let numVal = 0;
          if (cleanValues[normKey] !== undefined) {
            const parsed = parseFloat(String(cleanValues[normKey]));
            if (!isNaN(parsed) && parsed !== 0) numVal = parsed;
          } else if (cleanValues[col.key] !== undefined) {
            const parsed = parseFloat(String(cleanValues[col.key]));
            if (!isNaN(parsed) && parsed !== 0) numVal = parsed;
          }

          if (numVal === 0 && targetNorm) {
            for (const [vk, vv] of Object.entries(cleanValues)) {
              if (vk.toLowerCase().replace(/[^a-z0-9]/g, '') === targetNorm) {
                const parsed = typeof vv === 'number' ? vv : parseFloat(String(vv));
                if (!isNaN(parsed) && parsed !== 0) {
                  numVal = parsed;
                  break;
                }
              }
            }
          }

          rowObj[normKey] = numVal;
        });

        return rowObj;
      });

      const stockRes = await fetch('/api/stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entry_id, stock_rows: stockRows, stock_summary_rows: summaryRowsWithId }),
      });
      if (!stockRes.ok) {
        const d = await stockRes.json();
        throw new Error(d.error || 'Failed to save stock rows');
      }

      // 4. Automatically create / compile Solid Balance (STG) Entry for this date/shift
      try {
        await autoCompileSTGFromStock(entryDate, shift, columns, rows);
      } catch (stgErr) {
        console.error('Auto-compiling STG entry warning:', stgErr);
      }

      setSuccess('Stock Statement & STG Receipts & Disposals saved successfully!');

      if (nextAction === 'view') {
        router.push(`/dashboard/stock/${entryDate}/${shift}`);
      } else if (nextAction === 'next') {
        if (onDateShiftChange) onDateShiftChange(entryDate, shift);
        if (onNextStep) {
          (onNextStep as any)(entryDate, shift);
        } else {
          // Advance to next shift or day
          if (reportMode === 'shift') {
            if (shift === 'D') {
              setShift('N');
            } else {
              const [year, month, day] = entryDate.split('-').map(Number);
              const nextDate = new Date(year, month - 1, day + 1);
              const yyyy = nextDate.getFullYear();
              const mm = String(nextDate.getMonth() + 1).padStart(2, '0');
              const dd = String(nextDate.getDate()).padStart(2, '0');
              setEntryDate(`${yyyy}-${mm}-${dd}`);
              setShift('D');
            }
          } else {
            // Full Day mode: advance to next day
            const [year, month, day] = entryDate.split('-').map(Number);
            const nextDate = new Date(year, month - 1, day + 1);
            const yyyy = nextDate.getFullYear();
            const mm = String(nextDate.getMonth() + 1).padStart(2, '0');
            const dd = String(nextDate.getDate()).padStart(2, '0');
            setEntryDate(`${yyyy}-${mm}-${dd}`);
            setShift('F');
          }
        }
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const getSectionSum = (rowType: 'OB' | 'RECEIPT' | 'DISPOSAL', colKey: string): number => {
    return rows
      .filter(r => r.row_type === rowType)
      .reduce((sum, r) => sum + (parseFloat(r.values[colKey] || '0') || 0), 0);
  };

  const renderSection = (
    sectionLabel: string,
    rowTypes: StockRowState['row_type'][],
    headerColor: string
  ) => {
    const sRows = rows.map((r, i) => ({ r, i })).filter(x => rowTypes.includes(x.r.row_type));
    const isBalanceSection = rowTypes.includes('OB');
    const isReceiptsSection = sectionLabel === 'Receipts';
    const isDisposalsSection = sectionLabel === 'Disposals';
    const rowType = rowTypes[0]; // 'RECEIPT' or 'DISPOSAL'

    return (
      <div key={sectionLabel} className="entry-form-section">
        <div className="entry-form-section-title" style={{ color: headerColor, display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span>{sectionLabel}</span>
            {isBalanceSection && (
              <button
                type="button"
                className="btn btn-secondary btn-sm no-print"
                onClick={() => setObUnlocked(!obUnlocked)}
                style={{
                  padding: '4px 10px',
                  fontSize: '0.72rem',
                  height: 24,
                  lineHeight: 1,
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 4,
                  borderRadius: 4,
                  border: '1px solid var(--border)',
                  background: obUnlocked ? 'rgba(239, 68, 68, 0.1)' : 'rgba(14, 165, 233, 0.1)',
                  color: obUnlocked ? '#ef4444' : 'var(--brand-primary)',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                {obUnlocked ? '🔒 Lock OB' : '✏️ Edit OB'}
              </button>
            )}
            {isReceiptsSection && (
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm no-print"
                  onClick={() => {
                    const nextUnlocked = !receiptsUnlocked;
                    setReceiptsUnlocked(nextUnlocked);
                    if (nextUnlocked) {
                      setSuccess('Receipts unlocked. You can now update receipt values manually.');
                      setTimeout(() => setSuccess(''), 4000);
                    } else {
                      setSuccess('Receipts locked. Manual changes are saved.');
                      setTimeout(() => setSuccess(''), 4000);
                    }
                  }}
                  style={{
                    padding: '4px 10px',
                    fontSize: '0.72rem',
                    height: 24,
                    lineHeight: 1,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    borderRadius: 4,
                    border: '1px solid var(--border)',
                    background: receiptsUnlocked ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                    color: receiptsUnlocked ? '#ef4444' : '#047857',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {receiptsUnlocked ? '🔒 Lock Receipts' : '✏️ Edit Receipts'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm no-print"
                  onClick={async () => {
                    const count = await syncFromPreparationCharts();
                    if (count > 0) {
                      setReceiptsUnlocked(true);
                      setDisposalsUnlocked(true);
                      await showSuccess(
                        `Synced ${count} preparation formulation batch quantity(ies) into Stock Statement Entry! Receipts & Disposals updated and unlocked.`,
                        'Preparation Charts Synced'
                      );
                    } else {
                      await showWarning(
                        `No saved preparation charts data found for ${entryDate}. Please ensure preparation charts are saved for this date.`,
                        'No Preparation Charts Found'
                      );
                    }
                  }}
                  title="Auto-fill receipt quantities from saved Preparation Charts"
                  style={{
                    padding: '4px 10px',
                    fontSize: '0.72rem',
                    height: 24,
                    lineHeight: 1,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    borderRadius: 4,
                    border: '1px solid #0284c7',
                    background: 'rgba(14, 165, 233, 0.1)',
                    color: '#0284c7',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  ⚡ Sync Receipts from Prep Charts
                </button>
              </div>
            )}
            {isDisposalsSection && (
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm no-print"
                  onClick={() => {
                    const nextUnlocked = !disposalsUnlocked;
                    setDisposalsUnlocked(nextUnlocked);
                    if (nextUnlocked) {
                      setSuccess('Disposals unlocked. You can now update disposal values manually.');
                      setTimeout(() => setSuccess(''), 4000);
                    } else {
                      setSuccess('Disposals locked. Manual changes are saved.');
                      setTimeout(() => setSuccess(''), 4000);
                    }
                  }}
                  style={{
                    padding: '4px 10px',
                    fontSize: '0.72rem',
                    height: 24,
                    lineHeight: 1,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    borderRadius: 4,
                    border: '1px solid var(--border)',
                    background: disposalsUnlocked ? 'rgba(239, 68, 68, 0.1)' : 'rgba(245, 158, 11, 0.15)',
                    color: disposalsUnlocked ? '#ef4444' : '#b45309',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {disposalsUnlocked ? '🔒 Lock Disposals' : '✏️ Edit Disposals'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm no-print"
                  onClick={async () => {
                    const count = await syncFromPreparationCharts();
                    if (count > 0) {
                      setDisposalsUnlocked(true);
                      setReceiptsUnlocked(true);
                      await showSuccess(
                        `Synced ${count} preparation formulation batch quantity(ies) into Stock Statement Entry! Disposals & Receipts updated and unlocked.`,
                        'Preparation Charts Synced'
                      );
                    } else {
                      await showWarning(
                        `No saved preparation charts data found for ${entryDate}. Please ensure preparation charts are saved for this date.`,
                        'No Preparation Charts Found'
                      );
                    }
                  }}
                  title="Auto-fill disposal quantities from saved Preparation Charts"
                  style={{
                    padding: '4px 10px',
                    fontSize: '0.72rem',
                    height: 24,
                    lineHeight: 1,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    borderRadius: 4,
                    border: '1px solid #d97706',
                    background: 'rgba(245, 158, 11, 0.1)',
                    color: '#b45309',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  ⚡ Sync Disposals from Prep Charts
                </button>
              </div>
            )}
          </div>
          {(isReceiptsSection || isDisposalsSection) && (
            <Link
              href="/dashboard/stock/mappings"
              className="no-print"
              style={{ fontSize: '0.75rem', color: 'var(--brand-primary)', fontWeight: 600, textDecoration: 'none' }}
            >
              🔗 Configure Mappings ➔
            </Link>
          )}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="inline-table" style={{ minWidth: 1200 }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', minWidth: 220 }}>Particulars</th>
                {columns.map(col => {
                  const isMappedReceiptCol = isReceiptsSection && (
                    internalRules.some(rule => rule.enabled !== false && (rule.targetReceiptProductKey || rule.sourceProductKey) === col.key) ||
                    (internalRules.length === 0 && columns[0]?.key === col.key)
                  );

                  return (
                    <th key={col.key} style={{ minWidth: 110, fontSize: '0.65rem', textAlign: 'center', padding: '8px 4px', background: isMappedReceiptCol ? 'rgba(16,185,129,0.08)' : undefined }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                        <div
                          style={{ fontWeight: 700, color: isMappedReceiptCol ? '#059669' : 'inherit' }}
                          title={isMappedReceiptCol ? 'Auto-calculated from Disposals row total' : (col.full_name ? `${col.full_name} (${col.short_name || col.label})` : (col.short_name || col.label))}
                        >
                          {col.short_name || col.label} {isMappedReceiptCol ? '⚡' : ''}
                        </div>
                      </div>
                    </th>
                  );
                })}
                <th style={{ minWidth: 110, fontSize: '0.65rem', textAlign: 'center', padding: '8px 4px', fontWeight: 700 }}>Total</th>
                {!isBalanceSection && isDisposalsSection && <th className="no-print" style={{ width: 70 }}>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {sRows.map(({ r, i }) => {
                const mappedRule = internalRules.find(rule =>
                  rule.enabled !== false &&
                  (rule.sourceDisposalParticular || rule.targetDisposalParticular || '').trim().toLowerCase() === r.row_label.trim().toLowerCase()
                );
                const isMappedDisposalRow = isDisposalsSection && (
                  !!mappedRule ||
                  (internalRules.length === 0 && r.row_label.trim().toLowerCase() === 'to dlt milk')
                );
                const isFocusedRow = focusedRowIdx === i;

                return (
                  <tr
                    key={i}
                    style={{
                      backgroundColor: isFocusedRow
                        ? 'rgba(14, 165, 233, 0.14)'
                        : (isMappedDisposalRow ? '#fffbeb' : 'transparent'),
                      boxShadow: isFocusedRow ? 'inset 0 0 0 2px #0ea5e9' : 'none',
                      transition: 'all 0.12s ease',
                    }}
                  >
                    <td className="product-label" style={{ padding: 4 }}>
                      {isBalanceSection ? (
                        <span style={{ fontWeight: 600, paddingLeft: 8 }}>{r.row_label}</span>
                      ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                          <div style={{ display: 'flex', alignItems: 'center' }}>
                            <input
                              id={`stock-input-${i}-particulars`}
                              type="text"
                              placeholder="Enter Particulars..."
                              value={r.row_label}
                              onFocus={() => setFocusedRowIdx(i)}
                              onKeyDown={e => handleTableKeyDown(e, i, 'particulars')}
                              onChange={e => {
                                const val = e.target.value;
                                setRows(prev => {
                                  const next = [...prev];
                                  next[i] = { ...next[i], row_label: val };
                                  return next;
                                });
                              }}
                              style={{ textAlign: 'left', fontWeight: 500, border: 'none', background: 'transparent', width: '100%', padding: '4px 8px' }}
                            />
                            {isMappedDisposalRow && (
                              <span
                                style={{
                                  fontSize: '0.62rem',
                                  background: '#fef3c7',
                                  color: '#b45309',
                                  fontWeight: 700,
                                  padding: '1px 5px',
                                  borderRadius: 4,
                                  whiteSpace: 'nowrap',
                                  marginRight: 4,
                                }}
                                title="Row total auto-populates into Receipts"
                              >
                                📤 Feeds Receipts
                              </span>
                            )}
                          </div>

                          {/* Receipts Internal Partitions button shown strictly when mapped in Configuration */}
                          {isDisposalsSection && (isMappedDisposalRow || r.row_label.trim().toLowerCase().includes('dairy') || r.row_label.trim().toLowerCase().includes('dairies')) && (
                            <div style={{ paddingLeft: 8, paddingBottom: 4, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                              {isMappedDisposalRow && (
                                <button
                                  type="button"
                                  className="btn btn-secondary btn-xs"
                                  onClick={() => openPartitionModal(i, 'RECEIPTS_PARTITION')}
                                  title={`🔀 Configure Receipts Internal Partitions for "${r.row_label}"`}
                                  style={{
                                    fontSize: '0.72rem',
                                    fontWeight: 700,
                                    padding: '2px 8px',
                                    color: '#047857',
                                    background: '#d1fae5',
                                    border: '1px solid #6ee7b7',
                                    borderRadius: 4,
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 4,
                                    cursor: 'pointer',
                                  }}
                                >
                                  🔀 Receipts Internal Partitions {Array.isArray(mappedRule?.partitions) && mappedRule.partitions.length > 0 ? `(${mappedRule.partitions.length})` : ''}
                                </button>
                              )}

                              {(r.row_label.trim().toLowerCase().includes('dairy') || r.row_label.trim().toLowerCase().includes('dairies')) && (
                                <button
                                  type="button"
                                  className="btn btn-secondary btn-xs"
                                  onClick={() => openPartitionModal(i, 'DAIRY_BREAKDOWN')}
                                  title="🏢 Configure Destination Dairy Breakdown"
                                  style={{
                                    fontSize: '0.72rem',
                                    fontWeight: 700,
                                    padding: '2px 8px',
                                    color: 'var(--brand-primary)',
                                    background: '#eff6ff',
                                    border: '1px solid #93c5fd',
                                    borderRadius: 4,
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 4,
                                    cursor: 'pointer',
                                  }}
                                >
                                  🏢 Split SSM to Dairies
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                    {columns.map(col => {
                      const isReadOnly = (isBalanceSection && !obUnlocked) ||
                                         (isReceiptsSection && !receiptsUnlocked) ||
                                         (isDisposalsSection && !disposalsUnlocked);
                      const isCellFocused = focusedRowIdx === i && focusedColKey === col.key;
                      const displayVal = isCellFocused
                        ? (r.values[col.key] || '')
                        : formatCellVal(r.values[col.key], viewDecimals);

                      const cellTitle = isReadOnly
                        ? (isBalanceSection
                            ? 'Opening Balance locked. Click ✏️ Edit OB to unlock.'
                            : isReceiptsSection
                            ? 'Receipts locked. Click ✏️ Edit Receipts to edit manually, or ⚡ Sync from Prep Charts to sync.'
                            : 'Disposals locked. Click ✏️ Edit Disposals to edit manually.')
                        : (isBalanceSection
                            ? 'Opening Balance unlocked for manual editing.'
                            : isReceiptsSection
                            ? 'Receipts unlocked for manual editing.'
                            : 'Disposals unlocked for manual editing.');

                      return (
                        <td key={col.key}>
                          <input
                            id={`stock-input-${i}-${col.key}`}
                            type={isCellFocused ? 'number' : (viewDecimals === 'auto' ? 'number' : 'text')}
                            step="any"
                            inputMode="decimal"
                            placeholder="0"
                            value={displayVal}
                            onChange={e => updateCell(i, col.key, e.target.value)}
                            onFocus={() => {
                              setFocusedRowIdx(i);
                              setFocusedColKey(col.key);
                            }}
                            onBlur={() => {
                              setFocusedColKey(prev => (prev === col.key ? null : prev));
                            }}
                            onKeyDown={e => handleTableKeyDown(e, i, col.key)}
                            title={cellTitle}
                            style={{
                              fontFamily: 'var(--font-numbers)',
                              backgroundColor: isReadOnly ? '#f8fafc' : (isFocusedRow ? 'rgba(255, 255, 255, 0.8)' : 'transparent'),
                              color: isReadOnly ? '#64748b' : 'inherit',
                              fontWeight: isFocusedRow ? 600 : 'normal',
                              cursor: isReadOnly ? 'not-allowed' : 'text',
                            }}
                            readOnly={isReadOnly}
                            onWheel={e => e.currentTarget.blur()}
                          />
                        </td>
                      );
                    })}
                    <td style={{ padding: 4 }}>
                      <input
                        type="text"
                        value={(() => {
                          const total = columns.reduce((sum, col) => sum + (parseFloat(r.values[col.key] || '0') || 0), 0);
                          return total === 0 ? '' : formatSummaryVal(total, viewDecimals);
                        })()}
                        disabled
                        style={{
                          fontFamily: 'var(--font-numbers)',
                          fontWeight: 600,
                          backgroundColor: '#f1f5f9',
                          color: '#475569',
                          textAlign: 'center',
                          border: 'none',
                          width: '100%',
                          padding: '6px 8px',
                          cursor: 'not-allowed',
                        }}
                      />
                    </td>
                    {!isBalanceSection && isDisposalsSection && (
                      <td className="no-print" style={{ textAlign: 'center' }}>
                        {isMappedDisposalRow && (
                          <div style={{ display: 'flex', gap: 6, justifyContent: 'center', alignItems: 'center' }}>
                            <button
                              type="button"
                              style={{
                                background: 'rgba(245, 158, 11, 0.15)',
                                border: '1px solid #f59e0b',
                                borderRadius: 4,
                                cursor: 'pointer',
                                fontSize: '0.95rem',
                                padding: '2px 4px',
                              }}
                              title="🔀 Configure Receipts Internal Partitions Mapping"
                              onClick={() => openPartitionModal(i, 'RECEIPTS_PARTITION')}
                            >
                              🔀
                            </button>
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderSummaryTable = () => {
    return (
      <div className="entry-form-section" style={{ marginTop: 24 }}>
        <div className="entry-form-section-title" style={{ color: 'var(--brand-primary)' }}>
          📊 Stock Statement Summary (Live)
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="inline-table" style={{ minWidth: 1200 }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', minWidth: 220 }}>Summary Item</th>
                {columns.map(col => (
                  <th key={col.key} style={{ minWidth: 110, fontSize: '0.65rem', textAlign: 'center', padding: '8px 4px' }}>
                    <div style={{ fontWeight: 700 }}>{col.label}</div>
                  </th>
                ))}
                <th style={{ minWidth: 110, fontSize: '0.65rem', textAlign: 'center', padding: '8px 4px', fontWeight: 700 }}>Total</th>
                <th style={{ width: 70 }}></th>
              </tr>
            </thead>
            <tbody>
              {/* 1. Opening Balance */}
              <tr style={{ background: 'rgba(14, 165, 233, 0.04)', fontWeight: 600 }}>
                <td style={{ padding: '8px 12px', fontWeight: 600, color: 'var(--text-secondary)' }}>Opening Balance</td>
                {columns.map(col => {
                  const val = getSectionSum('OB', col.key);
                  return (
                    <td key={col.key} style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)' }}>
                      {formatSummaryVal(val, viewDecimals)}
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)', fontWeight: 700 }}>
                  {(() => {
                    const rowSum = columns.reduce((sum, col) => sum + getSectionSum('OB', col.key), 0);
                    return formatSummaryVal(rowSum, viewDecimals);
                  })()}
                </td>
                <td></td>
              </tr>
              {/* 2. Total Receipts */}
              <tr style={{ background: 'rgba(16, 185, 129, 0.02)', fontWeight: 600 }}>
                <td style={{ padding: '8px 12px', color: 'var(--text-secondary)' }}>Total Receipts (+)</td>
                {columns.map(col => {
                  const val = getSectionSum('RECEIPT', col.key);
                  return (
                    <td key={col.key} style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)' }}>
                      {formatSummaryVal(val, viewDecimals)}
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)', fontWeight: 700 }}>
                  {(() => {
                    const rowSum = columns.reduce((sum, col) => sum + getSectionSum('RECEIPT', col.key), 0);
                    return formatSummaryVal(rowSum, viewDecimals);
                  })()}
                </td>
                <td></td>
              </tr>
              {/* 3. TOTAL (OB + Receipts) */}
              <tr style={{ background: 'rgba(16, 185, 129, 0.08)', fontWeight: 700 }}>
                <td style={{ padding: '8px 12px', color: 'var(--text-primary)', fontWeight: 700 }}>TOTAL (OB + Receipts)</td>
                {columns.map(col => {
                  const obVal = getSectionSum('OB', col.key);
                  const recVal = getSectionSum('RECEIPT', col.key);
                  const val = obVal + recVal;
                  return (
                    <td key={col.key} style={{ textAlign: 'center', fontSize: '0.8rem', fontWeight: 700, padding: '8px 4px', fontFamily: 'var(--font-numbers)' }}>
                      {formatSummaryVal(val, viewDecimals)}
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)', fontWeight: 700 }}>
                  {(() => {
                    const rowSum = columns.reduce((sum, col) => sum + (getSectionSum('OB', col.key) + getSectionSum('RECEIPT', col.key)), 0);
                    return formatSummaryVal(rowSum, viewDecimals);
                  })()}
                </td>
                <td></td>
              </tr>
              {/* 4. Total Disposals */}
              <tr style={{ background: 'rgba(245, 158, 11, 0.02)', fontWeight: 600 }}>
                <td style={{ padding: '8px 12px', color: 'var(--text-secondary)' }}>Total Disposals (-)</td>
                {columns.map(col => {
                  const val = getSectionSum('DISPOSAL', col.key);
                  return (
                    <td key={col.key} style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)' }}>
                      {formatSummaryVal(val, viewDecimals)}
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)', fontWeight: 700 }}>
                  {(() => {
                    const rowSum = columns.reduce((sum, col) => sum + getSectionSum('DISPOSAL', col.key), 0);
                    return formatSummaryVal(rowSum, viewDecimals);
                  })()}
                </td>
                <td></td>
              </tr>
              {/* 5. Closing Balance */}
              <tr style={{ background: 'rgba(14, 165, 233, 0.12)', fontWeight: 700 }}>
                <td style={{ padding: '8px 12px', color: 'var(--text-primary)', fontWeight: 700 }}>Closing Balance (=)</td>
                {columns.map(col => {
                  const obVal = getSectionSum('OB', col.key);
                  const recVal = getSectionSum('RECEIPT', col.key);
                  const dispVal = getSectionSum('DISPOSAL', col.key);
                  const val = obVal + recVal - dispVal;
                  return (
                    <td key={col.key} style={{ textAlign: 'center', fontSize: '0.8rem', fontWeight: 700, padding: '8px 4px', color: val < 0 ? '#ef4444' : 'inherit', fontFamily: 'var(--font-numbers)' }}>
                      {formatSummaryVal(val, viewDecimals)}
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: '0.8rem', padding: '8px 4px', fontFamily: 'var(--font-numbers)', fontWeight: 700 }}>
                  {(() => {
                    const rowSum = columns.reduce((sum, col) => {
                      const obVal = getSectionSum('OB', col.key);
                      const recVal = getSectionSum('RECEIPT', col.key);
                      const dispVal = getSectionSum('DISPOSAL', col.key);
                      return sum + (obVal + recVal - dispVal);
                    }, 0);
                    return formatSummaryVal(rowSum, viewDecimals);
                  })()}
                </td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const handleStepClick = (key: string) => {
    if (onDateShiftChange) {
      onDateShiftChange(entryDate, shift);
    }
    if (onStepChange) {
      onStepChange(key);
      return;
    }
    const s = shift || 'F';
    if (key === 'prep') {
      if (onPrevStep) {
        (onPrevStep as any)(entryDate, s);
      } else {
        router.push(`/dashboard/stock/preparation-charts?date=${entryDate}&shift=${s}`);
      }
    } else if (key === 'stg') {
      router.push(`/dashboard/stock/new?step=stg&date=${entryDate}&shift=${s}`);
    } else if (key === 'ts') {
      router.push(`/dashboard/stock/new?step=ts&date=${entryDate}&shift=${s}`);
    } else if (key === 'reports') {
      router.push(`/dashboard/ts/${entryDate}?shift=${s}`);
    }
  };

  const syncFromPreparationCharts = async (): Promise<number> => {
    try {
      const s = shift || 'F';
      const res = await fetch(`/api/stock/preparation-charts?date=${entryDate}&shift=${s}`);
      if (!res.ok) return 0;
      const json = await res.json();
      const entries: Record<string, any> = json.entries || {};
      const mappingRules: any[] = json.mappings || [];
      const masters: any[] = json.masters || [];
      let mappedCount = 0;

      const norm = (str: any) => String(str || '').toLowerCase().replace(/[^a-z0-9]/g, '');

      setRows(prevRows => {
        const nextRows = [...prevRows];

        // Track fresh totals mapped from prep charts for each (targetRowIdx, targetColKey)
        // so that clicking Sync SETS/OVERWRITES the mapped quantities with the exact prep chart totals,
        // rather than accumulating on top of previously loaded/synced values.
        const syncedTotals: Record<number, Record<string, number>> = {};
        const affectedCells = new Set<string>(); // "targetRowIdx:colKey"
        const mappedBatchKeys = new Set<string>(); // deduplication key per batch source

        Object.keys(entries).forEach(chartKey => {
          const entry = entries[chartKey];
          const masterDef = masters.find((m: any) => m.key === chartKey);
          const chartVariantNorm = norm(masterDef?.product_variant || chartKey);

          // Get list of batches if present, or fallback to single entry object as batch 1
          const batchesList: any[] = Array.isArray(entry.batches) && entry.batches.length > 0
            ? entry.batches
            : [{
                rows: Array.isArray(entry.rows) ? entry.rows : [],
                target_batch_liters: entry.target_batch_liters,
                target_fat: entry.target_fat,
                target_snf: entry.target_snf,
              }];

          batchesList.forEach((batch: any, batchIdx: number) => {
            // Find active mapping rules for this chart / variant
            const matchingRules = mappingRules.filter(rule => {
              if (rule.enabled === false) return false;
              const isWildcardChart = !rule.sourceChartKey || rule.sourceChartKey === '*' || norm(rule.sourceChartKey) === '';
              const ruleChartNorm = norm(rule.sourceChartKey);
              const matchChart = isWildcardChart || ruleChartNorm === norm(chartKey) || (masterDef && (ruleChartNorm === norm(masterDef.name) || ruleChartNorm === norm(masterDef.key)));
              if (!matchChart) return false;

              // Parse (Row \d+) if present (e.g. "MILK (Row 2)", "Water (Row 9)")
              const rowMatch = (rule.sourceVariant || '').match(/\(Row\s*(\d+)\)/i);
              const targetRowIndex = rowMatch ? parseInt(rowMatch[1], 10) - 1 : -1;
              const cleanRuleVar = (rule.sourceVariant || '*').replace(/\(Row\s*\d+\)/i, '').trim();
              const ruleVarNorm = norm(cleanRuleVar || '*');

              if (!cleanRuleVar || cleanRuleVar === '*' || ruleVarNorm === '') return true;

              const bRows: any[] = Array.isArray(batch.rows) && batch.rows.length > 0 ? batch.rows : (Array.isArray(entry.rows) ? entry.rows : []);

              if (targetRowIndex >= 0 && targetRowIndex < bRows.length) {
                const r = bRows[targetRowIndex];
                const rVar = norm(r.variant || r.values?.variant || r.ingredient || r.name || r.item || '');
                if (ruleVarNorm === '' || rVar === ruleVarNorm || rVar.includes(ruleVarNorm) || ruleVarNorm.includes(rVar)) {
                  return true;
                }
              }

              const matchVar =
                ruleVarNorm === chartVariantNorm ||
                (chartVariantNorm !== '' && chartVariantNorm.includes(ruleVarNorm)) ||
                (chartVariantNorm !== '' && ruleVarNorm.includes(chartVariantNorm));

              if (matchVar) return true;

              // Also check if any row in batch matches ruleVarNorm
              return bRows.some((r: any) => {
                const rVar = norm(r.variant || r.values?.variant || r.ingredient || r.name || r.item || '');
                return rVar !== '' && (rVar === ruleVarNorm || rVar.includes(ruleVarNorm) || ruleVarNorm.includes(rVar));
              });
            });

            if (matchingRules.length > 0) {
              matchingRules.forEach(rule => {
                const preferredKey = rule.sourceColKey || 'qty_lit';
                const normPref = norm(preferredKey);

                let batchQty = 0;
                const targetBatchVol = Number(batch.target_batch_liters || entry.target_batch_liters || masterDef?.target_batch_liters || 0);

                const rowMatch = (rule.sourceVariant || '').match(/\(Row\s*(\d+)\)/i);
                const targetRowIndex = rowMatch ? parseInt(rowMatch[1], 10) - 1 : -1;
                const cleanRuleVar = (rule.sourceVariant || '*').replace(/\(Row\s*\d+\)/i, '').trim();
                const ruleVarNorm = norm(cleanRuleVar || '*');

                const isWildcardVariant = !cleanRuleVar || cleanRuleVar === '*' || ruleVarNorm === '';
                const isChartLevelVariant = isWildcardVariant || ruleVarNorm === chartVariantNorm || (chartVariantNorm !== '' && (chartVariantNorm.includes(ruleVarNorm) || ruleVarNorm.includes(chartVariantNorm)));

                const bRows: any[] = Array.isArray(batch.rows) && batch.rows.length > 0 ? batch.rows : (Array.isArray(entry.rows) ? entry.rows : []);

                // Helper to extract numeric value for preferred column key from a row values object
                const extractColVal = (vals: Record<string, any>, prefKey: string): number => {
                  const normP = norm(prefKey);
                  // Direct key lookup
                  if (vals[prefKey] !== undefined && vals[prefKey] !== null && vals[prefKey] !== '') {
                    const n = parseFloat(String(vals[prefKey]).replace(/,/g, ''));
                    if (!isNaN(n)) return n;
                  }
                  // Normalized exact key lookup
                  for (const [k, v] of Object.entries(vals)) {
                    if (v === undefined || v === null || v === '') continue;
                    if (norm(k) === normP) {
                      const n = parseFloat(String(v).replace(/,/g, ''));
                      if (!isNaN(n)) return n;
                    }
                  }
                  // Flexible fuzzy column key lookup (e.g. qty vs qty_lit or qty_kg vs kg)
                  for (const [k, v] of Object.entries(vals)) {
                    if (v === undefined || v === null || v === '') continue;
                    const nk = norm(k);
                    const isQtyMatch = (normP.includes('qty') || normP.includes('lit')) && (nk === 'qty' || nk === 'qtylit' || nk === 'volume' || nk === 'vol');
                    const isKgMatch = (normP.includes('kg') && !normP.includes('fat') && !normP.includes('snf')) && (nk === 'qtykg' || nk === 'kg');
                    const isFatMatch = (normP.includes('kgfat') || normP === 'kgfat') && (nk === 'kgfat' || nk === 'fatkg');
                    const isSnfMatch = (normP.includes('kgsnf') || normP === 'kgsnf') && (nk === 'kgsnf' || nk === 'snfkg');
                    if (isQtyMatch || isKgMatch || isFatMatch || isSnfMatch || nk.includes(normP) || normP.includes(nk)) {
                      const n = parseFloat(String(v).replace(/,/g, ''));
                      if (!isNaN(n)) return n;
                    }
                  }
                  // Fallback: if looking for qty_lit but only qty_kg is available (e.g. Water or SMP)
                  if (normP.includes('lit') || normP.includes('qty')) {
                    for (const altKey of ['qty_lit', 'qty_kg', 'qty', 'liters', 'kg']) {
                      if (vals[altKey] !== undefined && vals[altKey] !== null && vals[altKey] !== '') {
                        const n = parseFloat(String(vals[altKey]).replace(/,/g, ''));
                        if (!isNaN(n) && n > 0) return n;
                      }
                    }
                  }
                  return 0;
                };

                // 1. Search batch rows for matching variant row(s)
                let matchedRows: any[] = [];
                if (targetRowIndex >= 0 && targetRowIndex < bRows.length) {
                  // Direct row index match (e.g. Row 2, Row 6, Row 8, Row 9)
                  matchedRows = [bRows[targetRowIndex]];
                } else if (!isWildcardVariant) {
                  // Exact match on row variant
                  matchedRows = bRows.filter((r: any) => {
                    const rVar = norm(r.variant || r.values?.variant || r.ingredient || r.name || r.item || '');
                    return rVar === ruleVarNorm;
                  });

                  // If no exact match, try prefix / substring match
                  if (matchedRows.length === 0) {
                    matchedRows = bRows.filter((r: any) => {
                      const rVar = norm(r.variant || r.values?.variant || r.ingredient || r.name || r.item || '');
                      return rVar !== '' && (rVar.startsWith(ruleVarNorm) || ruleVarNorm.startsWith(rVar) || rVar.includes(ruleVarNorm));
                    });
                  }
                } else {
                  // Wildcard rule: search for chart product variant row first
                  if (chartVariantNorm !== '') {
                    matchedRows = bRows.filter((r: any) => {
                      const rVar = norm(r.variant || r.values?.variant || r.ingredient || r.name || r.item || '');
                      return rVar === chartVariantNorm;
                    });
                  }
                }

                if (matchedRows.length > 0) {
                  for (const r of matchedRows) {
                    const vals = r?.values || r || {};
                    const val = extractColVal(vals, preferredKey);
                    if (val > 0) {
                      batchQty += val;
                    }
                  }
                }

                // 2. Fallback: if no specific row value was found and this is a chart-level or wildcard rule, use targetBatchVol
                if (batchQty === 0 && (isWildcardVariant || isChartLevelVariant)) {
                  batchQty = targetBatchVol;
                }

                if (batchQty > 0) {
                  const targetRowType = rule.targetRowType || 'RECEIPT';
                  let targetRowIdx = -1;

                  if (rule.targetRowLabel && rule.targetRowLabel.trim() !== '') {
                    const normRuleLabel = norm(rule.targetRowLabel);
                    targetRowIdx = nextRows.findIndex(row =>
                      row.row_type === targetRowType &&
                      (
                        norm(row.row_label) === normRuleLabel ||
                        norm(row.row_label).includes(normRuleLabel) ||
                        normRuleLabel.includes(norm(row.row_label))
                      )
                    );

                    if (targetRowIdx === -1) {
                      const newRow: StockRowState = {
                        row_type: targetRowType,
                        row_label: rule.targetRowLabel.trim(),
                        values: {},
                      };
                      const lastSectionIdx = nextRows.map((x, i) => x.row_type === targetRowType ? i : -1).filter(i => i !== -1).pop();
                      if (lastSectionIdx !== undefined && lastSectionIdx >= 0) {
                        nextRows.splice(lastSectionIdx + 1, 0, newRow);
                        targetRowIdx = lastSectionIdx + 1;
                      } else {
                        nextRows.push(newRow);
                        targetRowIdx = nextRows.length - 1;
                      }
                    }
                  } else {
                    targetRowIdx = nextRows.findIndex(row => row.row_type === targetRowType);
                  }

                  if (targetRowIdx !== -1) {
                    const targetProdKey = rule.targetProductKey || '';
                    const normTargetProd = norm(targetProdKey);

                    const matchedCol = columns.find(c => {
                      const normColKey = norm(c.key);
                      const normColLabel = norm(c.label || c.short_name || c.full_name || '');
                      return (
                        c.key === targetProdKey ||
                        normColKey === normTargetProd ||
                        normColLabel === normTargetProd ||
                        (normTargetProd.includes('wh') && normColKey.includes('wh')) ||
                        (normTargetProd.includes('wm') && (normColKey.includes('wm') || normColKey.includes('wh'))) ||
                        (normTargetProd.includes('dlt') && normColKey.includes('dlt')) ||
                        (normTargetProd.includes('std') && normColKey.includes('std')) ||
                        (normTargetProd.includes('fcm') && normColKey.includes('fcm')) ||
                        (normTargetProd.includes('cream') && (normColKey.includes('cream') || normColKey.includes('butter'))) ||
                        (normTargetProd.includes('smp') && normColKey.includes('smp')) ||
                        (normTargetProd.includes('water') && normColKey.includes('water')) ||
                        (normTargetProd.includes('skim') && normColKey.includes('skim'))
                      );
                    });

                    if (matchedCol) {
                      const dedupKey = `b_${chartKey}_${batchIdx}_${rule.id || rule.rule_key || `${ruleVarNorm}_${normPref}`}_to_${targetRowIdx}_${matchedCol.key}`;
                      if (!mappedBatchKeys.has(dedupKey)) {
                        mappedBatchKeys.add(dedupKey);

                        if (!syncedTotals[targetRowIdx]) syncedTotals[targetRowIdx] = {};
                        syncedTotals[targetRowIdx][matchedCol.key] = (syncedTotals[targetRowIdx][matchedCol.key] || 0) + batchQty;
                        affectedCells.add(`${targetRowIdx}:${matchedCol.key}`);
                        mappedCount++;
                      }
                    }
                  }
                }
              });
            } else {
              // Smart Fallback matching per batch
              let batchQty = Number(batch.target_batch_liters || entry.target_batch_liters || 0);

              if (batchQty > 0) {
                const receiptIndices = nextRows
                  .map((row, i) => (row.row_type === 'RECEIPT' ? i : -1))
                  .filter(i => i !== -1);

                if (receiptIndices.length > 0) {
                  const targetIdx = receiptIndices[0];
                  const varUpper = (chartVariantNorm || '').toUpperCase();

                  const matchedCol = columns.find(c => {
                    const colLabel = (c.label || c.short_name || c.full_name || c.key).toUpperCase();
                    return (
                      colLabel === varUpper ||
                      (varUpper.includes('DELITE') && (colLabel.includes('DLT') || colLabel.includes('DELITE'))) ||
                      (varUpper.includes('FCM') && colLabel.includes('FCM')) ||
                      (varUpper.includes('STD') && (colLabel.includes('STD') || colLabel.includes('STANDARD'))) ||
                      (varUpper.includes('SKIM') && colLabel.includes('SKIM')) ||
                      (varUpper.includes('TONED') && colLabel.includes('TONED'))
                    );
                  });

                  if (matchedCol) {
                    const dedupKey = `fallback_${chartKey}_${batchIdx}_to_${targetIdx}_${matchedCol.key}`;
                    if (!mappedBatchKeys.has(dedupKey)) {
                      mappedBatchKeys.add(dedupKey);

                      if (!syncedTotals[targetIdx]) syncedTotals[targetIdx] = {};
                      syncedTotals[targetIdx][matchedCol.key] = (syncedTotals[targetIdx][matchedCol.key] || 0) + batchQty;
                      affectedCells.add(`${targetIdx}:${matchedCol.key}`);
                      mappedCount++;
                    }
                  }
                }
              }
            }
          });
        });

        // Apply calculated synced totals directly to nextRows (replacing previous values for affected cells)
        let hasReceiptsSynced = false;
        let hasDisposalsSynced = false;

        affectedCells.forEach(cellKey => {
          const [rowIdxStr, colKey] = cellKey.split(':');
          const rowIdx = parseInt(rowIdxStr, 10);
          if (!isNaN(rowIdx) && nextRows[rowIdx]) {
            const val = syncedTotals[rowIdx][colKey];
            const updatedRow = { ...nextRows[rowIdx], values: { ...nextRows[rowIdx].values } };
            updatedRow.values[colKey] = String(val);
            nextRows[rowIdx] = updatedRow;
            if (updatedRow.row_type === 'RECEIPT') hasReceiptsSynced = true;
            if (updatedRow.row_type === 'DISPOSAL') hasDisposalsSynced = true;
          }
        });

        if (hasReceiptsSynced) setReceiptsUnlocked(true);
        if (hasDisposalsSynced) setDisposalsUnlocked(true);

        return nextRows;
      });

      return mappedCount;
    } catch (err) {
      console.error('Failed to sync preparation charts:', err);
      return 0;
    }
  };

  const handleExportDailyExcel = async () => {
    if (!entryDate) {
      showWarning('Please select a valid date.', 'Date Required');
      return;
    }
    try {
      const shiftParam = shift ? `&shift=${shift}` : '';
      const url = `/api/export-excel?date=${entryDate}${shiftParam}&stock=true`;
      const res = await fetch(url);
      if (!res.ok) {
        let errJson: any = {};
        try { errJson = await res.json(); } catch {}
        const msg = errJson.error || 'Failed to export Excel stock statement. Please ensure entry data is saved first.';
        showWarning(msg, 'Export Notice');
        return;
      }
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      const dateParts = entryDate.split('-');
      const formattedDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
      const shiftStr = shift ? `-${shift}` : '';
      a.download = `Stock-Statement-${formattedDate}${shiftStr}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error(err);
      showError('Failed to export Excel stock statement', 'Export Error');
    }
  };

  const handlePrevStage = () => {
    if (onDateShiftChange) onDateShiftChange(entryDate, shift);
    if (onPrevStep) {
      (onPrevStep as any)(entryDate, shift);
    } else {
      router.push(`/dashboard/stock/preparation-charts?date=${entryDate}${shift ? `&shift=${shift}` : ''}`);
    }
  };

  return (
    <>
      <Header
        title="Milk & Cream Stock Statement Entry"
        subtitle={`Enter daily milk & cream stock data (${reportMode === 'full_day' ? 'Full Day' : (shift === 'D' ? 'Day Shift' : 'Night Shift')})`}
      >
        <Step
          items={DAILY_ENTRY_STEP_ITEMS}
          flat={true}
          activeStep={activeStep || 'stock'}
          onStepClick={handleStepClick}
          style={{ marginBottom: 0, marginTop: 4 }}
        />
      </Header>
      <div className="form-container">
        {/* Header */}
        <div className="card" style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div className="section-title" style={{ margin: 0 }}>Entry Details</div>
              <div style={{ display: 'flex', gap: 6 }} className="no-print">
                <Link
                  href="/dashboard/stock/defaults"
                  className="btn btn-secondary btn-xs"
                  style={{ borderColor: '#86efac', color: '#166534', backgroundColor: '#f0fdf4', fontSize: '0.75rem', padding: '4px 10px', fontWeight: 600 }}
                  title="Configure Master Default Statement Template for Milk & Cream Stock Statement Entry"
                >
                  ⭐ Master Default Statement
                </Link>
                <button
                  type="button"
                  className="btn btn-secondary btn-xs"
                  style={{ borderColor: '#d97706', color: '#b45309', backgroundColor: '#fffbeb', fontSize: '0.75rem', padding: '4px 10px', fontWeight: 600 }}
                  onClick={handlePrevStage}
                  title="Previous Stage: View Preparation Charts for selected Date & Shift"
                >
                  📋 Preparation Charts
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-xs"
                  style={{ borderColor: '#0284c7', color: '#0284c7', backgroundColor: '#f0f9ff', fontSize: '0.75rem', padding: '4px 10px', fontWeight: 600 }}
                  onClick={async () => {
                    const count = await syncFromPreparationCharts();
                    if (count > 0) {
                      setReceiptsUnlocked(true);
                      setDisposalsUnlocked(true);
                      await showSuccess(
                        `Synced ${count} preparation formulation batch quantity(ies) into Stock Statement Entry! Receipts & Disposals populated and unlocked.`,
                        'Preparation Charts Synced'
                      );
                    } else {
                      await showWarning(
                        `No saved preparation charts data found for ${entryDate}. Please ensure preparation charts are saved for this date.`,
                        'No Preparation Charts Found'
                      );
                    }
                  }}
                  title="Auto-fill receipt and disposal quantities from saved Preparation Charts"
                >
                  ⚡ Sync from Prep Charts
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-xs"
                  onClick={() => window.print()}
                  style={{ fontSize: '0.75rem', padding: '4px 10px' }}
                >
                  🖨️ Print
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-xs"
                  style={{ borderColor: '#16a34a', color: '#16a34a', fontSize: '0.75rem', padding: '4px 10px', fontWeight: 600 }}
                  onClick={handleExportDailyExcel}
                >
                  📥 Excel
                </button>

                {/* Decimal View Precision Selector */}
                <div
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    backgroundColor: '#f8fafc',
                    border: '1px solid #cbd5e1',
                    borderRadius: 6,
                    padding: '2px 4px',
                    gap: 2,
                    marginLeft: 4,
                  }}
                  title="Toggle decimal precision across all cells and totals in the statement"
                >
                  <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#475569', padding: '0 4px', display: 'flex', alignItems: 'center', gap: 3 }}>
                    🔢 View:
                  </span>
                  {([
                    { key: 'auto', label: 'Auto' },
                    { key: 0, label: '.0 Whole' },
                    { key: 1, label: '.1 Dec' },
                    { key: 2, label: '.2 Decs' },
                    { key: 3, label: '.3 Decs' },
                  ] as const).map(opt => {
                    const active = viewDecimals === opt.key;
                    return (
                      <button
                        key={String(opt.key)}
                        type="button"
                        onClick={() => setViewDecimals(opt.key)}
                        style={{
                          border: active ? '1px solid #0284c7' : '1px solid transparent',
                          borderRadius: 4,
                          padding: '2px 7px',
                          fontSize: '0.72rem',
                          fontWeight: active ? 700 : 500,
                          backgroundColor: active ? '#0284c7' : 'transparent',
                          color: active ? '#ffffff' : '#64748b',
                          cursor: 'pointer',
                          boxShadow: active ? '0 1px 2px rgba(2,132,199,0.2)' : 'none',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={handlePrevStage}
                disabled={saving}
                style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600 }}
                title="Go back to previous stage: Preparation Charts"
              >
                ← Back to Preparation Charts
              </button>
              <button
                type="button"
                className="btn btn-primary btn-sm"
                disabled={saving}
                onClick={async () => {
                  if (stepMode) {
                    await handleSave('next');
                  } else {
                    await handleSave('stay');
                    if (onStepChange) {
                      onStepChange('stg');
                    } else {
                      router.push(`/dashboard/stock/new?step=stg&date=${entryDate}${shift ? `&shift=${shift}` : ''}`);
                    }
                  }
                }}
                style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', fontWeight: 600, background: 'linear-gradient(135deg, #0284c7 0%, #0d9488 100%)', borderColor: '#0284c7' }}
              >
                {saving ? 'Saving...' : '💾 Save & Open Solid Balance (STG) Entry ➔'}
              </button>
            </div>
          </div>
          <div className="form-row form-row-3">
            <div className="form-group">
              <label className="form-label">Date *</label>
              <input
                id="stock-entry-date"
                type="date"
                className="form-input"
                value={entryDate}
                onChange={e => {
                  const newDate = e.target.value;
                  setEntryDate(newDate);
                  if (onDateShiftChange) onDateShiftChange(newDate, shift);
                }}
                max={new Date().toISOString().split('T')[0]}
              />
            </div>
            {reportMode === 'shift' ? (
              <div className="form-group">
                <label className="form-label">Shift *</label>
                <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                  {(['D', 'N'] as Shift[]).map(s => {
                    const cfg = shiftConfigs.find(c => c.key === s) || {
                      label: s === 'D' ? 'Day Shift' : 'Night Shift',
                      start: s === 'D' ? '06:00' : '18:00',
                      end: s === 'D' ? '18:00' : '06:00'
                    };
                    return (
                      <button
                        key={s}
                        id={`shift-${s}`}
                        type="button"
                        className={`btn ${shift === s ? 'btn-primary' : 'btn-secondary'}`}
                        onClick={() => {
                          setShift(s);
                          if (onDateShiftChange) onDateShiftChange(entryDate, s);
                        }}
                        style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2, padding: '6px 12px', height: 'auto', alignItems: 'center', justifyContent: 'center' }}
                      >
                        <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>
                          {s === 'D' ? '☀️' : '🌙'} {cfg.label}
                        </div>
                        <div style={{ fontSize: '0.7rem', opacity: 0.85 }}>
                          {cfg.start} - {cfg.end}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="form-group">
                <label className="form-label">Shift</label>
                <input
                  type="text"
                  className="form-input"
                  value="F (Full Day)"
                  disabled
                  style={{ background: '#f1f5f9', color: '#1e293b', fontWeight: 600, cursor: 'not-allowed' }}
                />
              </div>
            )}
            <div className="form-group">
              <label className="form-label">Notes (optional)</label>
              <input
                type="text"
                className="form-input"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="e.g. Holiday, machine maintenance..."
              />
            </div>
          </div>
        </div>

        {error && <div className="alert alert-error">⚠️ {error}</div>}
        {success && <div className="alert alert-success">✅ {success}</div>}

        {columns.length === 0 ? (
          <div className="card" style={{ padding: 45, textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: 12 }}>⭐</div>
            <div style={{ fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)', marginBottom: 6 }}>
              No Master Default Stock Statement Configured in Database
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: 20 }}>
              Configure your master statement template (products, receipt particulars, disposal particulars) from the Master Default Stock Statements page.
            </div>
            <Link href="/dashboard/stock/defaults" className="btn btn-primary btn-sm">
              ⭐ Open Master Default Stock Statements Configuration
            </Link>
          </div>
        ) : (
          <>
            {renderSection('Opening Balance', ['OB'], '#0ea5e9')}
            {renderSection('Receipts', ['RECEIPT'], '#10b981')}
            {renderSection('Disposals', ['DISPOSAL'], '#f59e0b')}

            {renderSummaryTable()}

            {/* Actions */}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'space-between', alignItems: 'center', marginTop: 16, flexWrap: 'wrap' }} className="no-print">
              <div>
                <button className="btn btn-secondary" onClick={() => router.back()} disabled={saving}>
                  Cancel
                </button>
              </div>
              <div style={{ display: 'flex', gap: 12 }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => handleSave('stay')}
                  disabled={saving}
                  style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                >
                  💾 Save progress
                </button>
                {stepMode ? (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handleSave('next')}
                    disabled={saving}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 6,
                      background: 'linear-gradient(135deg, #0ea5e9 0%, #10b981 100%)',
                      borderColor: '#0ea5e9',
                      fontWeight: 700,
                      boxShadow: '0 4px 12px rgba(14, 165, 233, 0.25)',
                    }}
                  >
                    {saving ? (
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <span className="spinner" style={{ width: 16, height: 16 }} /> Compiling STG &amp; TS...
                      </span>
                    ) : (
                      'Next: Proceed to Solid Balance (STG) ➔'
                    )}
                  </button>
                ) : (
                  <div style={{ display: 'flex', gap: 12 }}>
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => handleSave('next')}
                      disabled={saving}
                      style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                    >
                      ⏭️ Save &amp; Continue (Next)
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={async () => {
                        await handleSave('stay');
                        if (onStepChange) {
                          onStepChange('stg');
                        } else {
                          router.push(`/dashboard/stock/new?step=stg&date=${entryDate}${shift ? `&shift=${shift}` : ''}`);
                        }
                      }}
                      disabled={saving}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg, #0284c7 0%, #0d9488 100%)', borderColor: '#0284c7' }}
                    >
                      💾 Save &amp; Open Solid Balance (STG) Entry ➔
                    </button>
                  </div>
                )}
                <button
                  id="stock-save-btn"
                  className="btn btn-primary"
                  onClick={() => handleSave('view')}
                  disabled={saving}
                  style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                >
                  {saving ? 'Saving…' : '💾 Save & View Report'}
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* 🔀 Partition / Split Mapping Modal Overlay */}
      {partitionModalOpen && activePartitionRowIdx !== null && (
        <div
          className="no-print"
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.65)',
            backdropFilter: 'blur(4px)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20,
          }}
        >
          <div
            className="card animate-fade-in"
            style={{
              maxWidth: 580,
              width: '100%',
              background: '#ffffff',
              borderRadius: 12,
              boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
              border: '1px solid var(--border)',
              padding: 24,
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '1.1rem', color: 'var(--brand-primary)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span>{partitionModalTab === 'DAIRY_BREAKDOWN' ? '🏢 Destination Dairy Breakdown Configuration' : '🔄 Receipts Internal Partitions Configuration'}</span>
                </div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: 4 }}>
                  Particulars: <strong style={{ color: '#d97706' }}>{(activePartitionRowIdx !== null ? rows[activePartitionRowIdx]?.row_label : '') || 'Disposal Row'}</strong>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPartitionModalOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2rem', color: 'var(--text-muted)' }}
              >
                ✖
              </button>
            </div>



            <datalist id="preset-dairies-list">
              {presetDairies.map(p => (
                <option key={p} value={p} />
              ))}
            </datalist>

            {partitionModalTab === 'DAIRY_BREAKDOWN' ? (
              <>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: 8 }}>
                  Specify destination dairy split lines. These values will generate individual disposal lines in the Solid Balance (STG) Statement.
                </div>

                {/* Quick Add Preset Dairies + User Add Custom Preset */}
                <div style={{ marginBottom: 12, background: '#fafafa', border: '1px solid var(--border)', borderRadius: 8, padding: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span>⚡ Quick Add Preset Dairy Destination:</span>
                    </div>
                    {!showAddPresetInput && (
                      <button
                        type="button"
                        className="btn btn-ghost btn-xs"
                        onClick={() => setShowAddPresetInput(true)}
                        style={{ fontSize: '0.72rem', color: 'var(--brand-primary)', fontWeight: 700, padding: '1px 6px' }}
                      >
                        ➕ Add Destination
                      </button>
                    )}
                  </div>

                  {showAddPresetInput && (
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8, background: '#fff', padding: 6, borderRadius: 6, border: '1px solid #cbd5e1' }}>
                      <input
                        type="text"
                        placeholder="Enter dairy preset name (e.g. Trichy-SSM)..."
                        className="form-input"
                        style={{ fontSize: '0.78rem', padding: '3px 8px', height: 28, flex: 1, fontWeight: 600 }}
                        value={newPresetInput}
                        onChange={e => setNewPresetInput(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = newPresetInput.trim();
                            if (val) {
                              if (!presetDairies.some(p => p.toLowerCase() === val.toLowerCase())) {
                                setPresetDairies(prev => [...prev, val]);
                              }
                              const defaultProdKey = columns.find(c => c.key === 'skim_milk') ? 'skim_milk' : (columns[0]?.key || 'skim_milk');
                              setActiveDairyBreakdownItems(prev => {
                                if (!prev.some(item => item.dairy_name.trim().toLowerCase() === val.toLowerCase())) {
                                  if (prev.length === 1 && prev[0].dairy_name === '' && prev[0].value === '') {
                                    return [{ dairy_name: val, product_key: defaultProdKey, value: '' }];
                                  }
                                  return [...prev, { dairy_name: val, product_key: defaultProdKey, value: '' }];
                                }
                                return prev;
                              });
                              setNewPresetInput('');
                              setShowAddPresetInput(false);
                            }
                          }
                        }}
                      />
                      <button
                        type="button"
                        className="btn btn-primary btn-xs"
                        style={{ fontSize: '0.72rem', height: 28, padding: '0 10px', fontWeight: 600 }}
                        onClick={() => {
                          const val = newPresetInput.trim();
                          if (val) {
                            if (!presetDairies.some(p => p.toLowerCase() === val.toLowerCase())) {
                              setPresetDairies(prev => [...prev, val]);
                            }
                            const defaultProdKey = columns.find(c => c.key === 'skim_milk') ? 'skim_milk' : (columns[0]?.key || 'skim_milk');
                            setActiveDairyBreakdownItems(prev => {
                              if (!prev.some(item => item.dairy_name.trim().toLowerCase() === val.toLowerCase())) {
                                if (prev.length === 1 && prev[0].dairy_name === '' && prev[0].value === '') {
                                  return [{ dairy_name: val, product_key: defaultProdKey, value: '' }];
                                }
                                return [...prev, { dairy_name: val, product_key: defaultProdKey, value: '' }];
                              }
                              return prev;
                            });
                            setNewPresetInput('');
                            setShowAddPresetInput(false);
                          }
                        }}
                      >
                        ➕ Add
                      </button>
                      <button
                        type="button"
                        className="btn btn-secondary btn-xs"
                        style={{ fontSize: '0.72rem', height: 28, padding: '0 6px' }}
                        onClick={() => setShowAddPresetInput(false)}
                      >
                        ✖
                      </button>
                    </div>
                  )}

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {presetDairies.map(pDairy => {
                      const existingItem = activeDairyBreakdownItems.find(
                        item => item.dairy_name.trim().toLowerCase() === pDairy.toLowerCase()
                      );
                      const isAdded = !!existingItem;
                      const hasVal = isAdded && existingItem.value !== undefined && String(existingItem.value).trim() !== '';

                      return (
                        <button
                          key={pDairy}
                          type="button"
                          onClick={() => {
                            const defaultProdKey = columns.find(c => c.key === 'skim_milk') ? 'skim_milk' : (columns[0]?.key || 'skim_milk');
                            setActiveDairyBreakdownItems(prev => {
                              if (isAdded) {
                                // Toggle off: Remove from active list
                                const filtered = prev.filter(item => item.dairy_name.trim().toLowerCase() !== pDairy.toLowerCase());
                                return filtered.length > 0 ? filtered : [{ dairy_name: '', product_key: defaultProdKey, value: '' }];
                              } else {
                                // Toggle on: Add to active list
                                if (prev.length === 1 && prev[0].dairy_name === '' && prev[0].value === '') {
                                  return [{ dairy_name: pDairy, product_key: defaultProdKey, value: '' }];
                                }
                                return [...prev, { dairy_name: pDairy, product_key: defaultProdKey, value: '' }];
                              }
                            });
                          }}
                          style={{
                            background: isAdded ? 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)' : '#ffffff',
                            border: `1px solid ${isAdded ? '#f59e0b' : '#cbd5e1'}`,
                            borderRadius: 6,
                            padding: '3px 8px',
                            fontSize: '0.72rem',
                            fontWeight: isAdded ? 700 : 600,
                            color: isAdded ? '#b45309' : '#334155',
                            cursor: 'pointer',
                            transition: 'all 0.1s ease',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 4,
                            boxShadow: isAdded ? '0 1px 2px rgba(245,158,11,0.2)' : 'none',
                          }}
                          title={isAdded ? `Click to remove ${pDairy} split` : `Click to add ${pDairy} split`}
                        >
                          <span>{isAdded ? '➖' : '➕'} {pDairy}</span>
                          {hasVal && (
                            <span style={{ background: '#d97706', color: '#fff', padding: '1px 5px', borderRadius: 8, fontSize: '0.65rem', fontFamily: 'var(--font-numbers)' }}>
                              {parseFloat(existingItem.value).toLocaleString('en-IN')}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 260, overflowY: 'auto', paddingRight: 4, marginBottom: 16 }}>
                  {activeDairyBreakdownItems.map((item, dIdx) => (
                    <div key={dIdx} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                      <input
                        type="text"
                        list="preset-dairies-list"
                        placeholder="Destination Dairy..."
                        className="form-input"
                        style={{ flex: 1, fontSize: '0.85rem', fontWeight: 600 }}
                        value={item.dairy_name}
                        onChange={e => {
                          const val = e.target.value;
                          setActiveDairyBreakdownItems(prev => {
                            const next = [...prev];
                            next[dIdx] = { ...next[dIdx], dairy_name: val };
                            return next;
                          });
                        }}
                      />

                      <select
                        className="form-select"
                        style={{ width: 140, fontSize: '0.82rem' }}
                        value={item.product_key}
                        onChange={e => {
                          const val = e.target.value;
                          setActiveDairyBreakdownItems(prev => {
                            const next = [...prev];
                            next[dIdx] = { ...next[dIdx], product_key: val };
                            return next;
                          });
                        }}
                      >
                        {columns.map(col => (
                          <option key={col.key} value={col.key}>
                            {col.label}
                          </option>
                        ))}
                      </select>

                      <input
                        type="number"
                        step="any"
                        placeholder="Qty Value..."
                        className="form-input"
                        style={{ width: 120, fontFamily: 'var(--font-numbers)', fontSize: '0.85rem', fontWeight: 600 }}
                        value={item.value}
                        onChange={e => {
                          const val = e.target.value;
                          setActiveDairyBreakdownItems(prev => {
                            const next = [...prev];
                            next[dIdx] = { ...next[dIdx], value: val };
                            return next;
                          });
                        }}
                      />

                      <button
                        type="button"
                        style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.1rem', color: '#ef4444' }}
                        title="Remove dairy item"
                        onClick={() => {
                          setActiveDairyBreakdownItems(prev => prev.filter((_, idx) => idx !== dIdx));
                        }}
                      >
                        ❌
                      </button>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    style={{ fontSize: '0.78rem' }}
                    onClick={() => {
                      const defaultProdKey = columns.find(c => c.key === 'skim_milk') ? 'skim_milk' : (columns[0]?.key || 'skim_milk');
                      setActiveDairyBreakdownItems(prev => [
                        ...prev,
                        { dairy_name: '', product_key: defaultProdKey, value: '' },
                      ]);
                    }}
                  >
                    ➕ Add Dairy Destination
                  </button>

                  <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--brand-primary)', fontFamily: 'var(--font-numbers)' }}>
                    Total Split Qty: {activeDairyBreakdownItems.reduce((sum, i) => sum + (parseFloat(i.value || '0') || 0), 0).toLocaleString('en-IN')}
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Receipts Partition Tab View */}
                {(() => {
                  const rowValSum = columns.reduce(
                    (sum, col) => sum + (parseFloat((activePartitionRowIdx !== null ? rows[activePartitionRowIdx]?.values[col.key] : '0') || '0') || 0), 0
                  );
                  const partitionSum = partitionItems.reduce(
                    (sum, p) => sum + (parseFloat(p.value || '0') || 0), 0
                  );
                  const remaining = rowValSum - partitionSum;

                  return (
                    <div
                      style={{
                        background: 'linear-gradient(135deg, rgba(245,158,11,0.1) 0%, rgba(14,165,233,0.08) 100%)',
                        border: '1px solid rgba(245,158,11,0.3)',
                        borderRadius: 8,
                        padding: 12,
                        marginBottom: 20,
                        display: 'flex',
                        justifyContent: 'space-around',
                        textAlign: 'center',
                        fontFamily: 'var(--font-numbers)',
                      }}
                    >
                      <div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Row Total Qty</div>
                        <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#b45309' }}>
                          {rowValSum === 0 ? '—' : rowValSum.toLocaleString('en-IN')}
                        </div>
                      </div>
                      <div style={{ borderLeft: '1px solid var(--border)', paddingLeft: 16 }}>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Partitioned Total</div>
                        <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#10b981' }}>
                          {partitionSum === 0 ? '—' : partitionSum.toLocaleString('en-IN')}
                        </div>
                      </div>
                      <div style={{ borderLeft: '1px solid var(--border)', paddingLeft: 16 }}>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Difference</div>
                        <div style={{ fontSize: '1.1rem', fontWeight: 700, color: remaining < 0 ? '#ef4444' : (remaining === 0 ? '#10b981' : '#64748b') }}>
                          {remaining === 0 ? '0' : remaining.toLocaleString('en-IN')}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Partition rows builder */}
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: 8, color: 'var(--text-primary)' }}>
                    Target Receipts Partitions (e.g. Skim Milk, Cream):
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 260, overflowY: 'auto', paddingRight: 4 }}>
                    {partitionItems.map((part, pIdx) => (
                      <div key={pIdx} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                        <select
                          className="form-select"
                          style={{ flex: 1, fontSize: '0.85rem' }}
                          value={part.targetKey}
                          onChange={e => {
                            const newKey = e.target.value;
                            setPartitionItems(prev => {
                              const next = [...prev];
                              next[pIdx] = { ...next[pIdx], targetKey: newKey };
                              return next;
                            });
                          }}
                        >
                          {columns.map(col => (
                            <option key={col.key} value={col.key}>
                              Receipts: {col.label} ({col.short_name || col.key})
                            </option>
                          ))}
                        </select>

                        <input
                          type="number"
                          step="any"
                          placeholder="Enter value..."
                          className="form-input"
                          style={{ width: 140, fontFamily: 'var(--font-numbers)', fontSize: '0.85rem', fontWeight: 600 }}
                          value={part.value}
                          onChange={e => {
                            const val = e.target.value;
                            setPartitionItems(prev => {
                              const next = [...prev];
                              next[pIdx] = { ...next[pIdx], value: val };
                              return next;
                            });
                          }}
                        />

                        <button
                          type="button"
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.1rem', color: '#ef4444' }}
                          title="Remove partition"
                          onClick={() => {
                            setPartitionItems(prev => prev.filter((_, idx) => idx !== pIdx));
                          }}
                        >
                          ❌
                        </button>
                      </div>
                    ))}
                  </div>

                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    style={{ marginTop: 12, fontSize: '0.78rem' }}
                    onClick={() => {
                      const unusedCol = columns.find(c => !partitionItems.some(p => p.targetKey === c.key));
                      setPartitionItems(prev => [
                        ...prev,
                        { targetKey: unusedCol?.key || columns[0]?.key || 'skim_milk', value: '' },
                      ]);
                    }}
                  >
                    ➕ Add Partition Target
                  </button>
                </div>
              </>
            )}

            {/* Modal Actions */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => setPartitionModalOpen(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={handleSavePartitions}
              >
                💾 {partitionModalTab === 'DAIRY_BREAKDOWN' ? 'Apply & Save Dairy Breakdown' : 'Apply & Update Receipts'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
